import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { NextResponse } from "next/server";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function calculateAge(dateOfBirth: Date | string): number {
  const dob = new Date(dateOfBirth);
  const diff = Date.now() - dob.getTime();
  return Math.floor(diff / (365.25 * 24 * 60 * 60 * 1000));
}

export const MIN_DATING_AGE = 18;

/** Window within which repeated photo views from the same viewer don't re-count. */
export const PHOTO_VIEW_DEBOUNCE_MS = 6 * 60 * 60 * 1000; // 6 hours

/** Standard JSON error envelope used across all API routes. */
export function apiError(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export function apiOk<T>(data: T, status = 200) {
  return NextResponse.json(data, { status });
}

/** Wraps a route handler, converting thrown UnauthorizedError/ForbiddenError/ZodError into proper responses. */
export function handleApiError(err: unknown) {
  if (err && typeof err === "object" && "status" in err && typeof (err as any).status === "number") {
    return apiError((err as Error).message, (err as any).status);
  }
  if (err && typeof err === "object" && "issues" in (err as any)) {
    // ZodError
    const messages = (err as any).issues.map((i: any) => i.message).join("; ");
    return apiError(messages || "Invalid input", 422);
  }
  console.error(err);
  return apiError("Something went wrong. Please try again.", 500);
}
