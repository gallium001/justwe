import { db } from "@/lib/db";
import bcrypt from "bcryptjs";

let counter = 0;

export async function makeUser(overrides: Partial<Parameters<typeof db.user.create>[0]["data"]> = {}) {
  counter += 1;
  return db.user.create({
    data: {
      email: `test-user-${counter}-${Date.now()}@example.com`,
      passwordHash: await bcrypt.hash("Password123", 4),
      firstName: `Test${counter}`,
      dateOfBirth: new Date("1995-01-01"),
      country: "US",
      emailVerified: new Date(),
      datingProfileActive: true,
      datingIntentConfirmedAt: new Date(),
      ...overrides,
    },
  });
}

export async function makeCommunity(hostId: string, overrides: Partial<Parameters<typeof db.community.create>[0]["data"]> = {}) {
  counter += 1;
  return db.community.create({
    data: {
      hostId,
      name: `Test Community ${counter}`,
      description: "A test community",
      rules: "Be kind",
      visibility: "PUBLIC",
      geographicFocus: "WORLDWIDE",
      ...overrides,
    },
  });
}

export async function approveMembership(communityId: string, userId: string, decidedBy: string) {
  return db.communityMembership.create({
    data: { communityId, userId, status: "APPROVED", decidedAt: new Date(), decidedBy },
  });
}

export async function pendingMembership(communityId: string, userId: string) {
  return db.communityMembership.create({
    data: { communityId, userId, status: "PENDING" },
  });
}
