/**
 * Development seed data for JustWe.
 * Run with: npm run db:seed
 *
 * Produces:
 *  - An admin account
 *  - Several hosts with communities (including one worldwide community)
 *  - Members from multiple countries, including an explicit long-distance
 *    pair (Finland <-> Kenya) who share the worldwide community and can
 *    discover each other despite the distance
 *  - Pending and approved membership requests
 *  - Dating profiles with multiple photos each and seeded view counts
 *  - Likes, a pending mutual match, and an approved match with messages
 *  - Community posts and notifications
 *
 * All data is fake/development-only.
 */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

const PASSWORD = "Password123"; // dev-only password for every seeded account
const PLACEHOLDER_PHOTO = (seed: string) => `https://picsum.photos/seed/${seed}/800/1000`;

async function hash(pw: string) {
  return bcrypt.hash(pw, 10);
}

async function main() {
  console.log("Seeding JustWe development data...");

  // ---------- Admin ----------
  const admin = await db.user.upsert({
    where: { email: "admin@justwe.dev" },
    update: {},
    create: {
      email: "admin@justwe.dev",
      passwordHash: await hash(PASSWORD),
      firstName: "JustWe Admin",
      dateOfBirth: new Date("1985-01-01"),
      country: "US",
      role: "ADMIN",
      emailVerified: new Date(),
    },
  });

  // ---------- Hosts ----------
  const sarah = await db.user.upsert({
    where: { email: "sarah.host@justwe.dev" },
    update: {},
    create: {
      email: "sarah.host@justwe.dev",
      passwordHash: await hash(PASSWORD),
      firstName: "Sarah",
      dateOfBirth: new Date("1990-04-12"),
      gender: "FEMALE",
      country: "FI",
      region: "Central Finland",
      city: "Jyväskylä",
      locationVisibility: "REGION_COUNTRY",
      bio: "Hosting a warm, worldwide community for serious-minded singles.",
      profilePhotoUrl: PLACEHOLDER_PHOTO("sarah"),
      isHost: true,
      datingProfileActive: true,
      datingIntentConfirmedAt: new Date(),
      jwStatus: "BAPTIZED_PUBLISHER",
      relationshipGoals: "Marriage-minded",
      longDistancePreference: "YES",
      emailVerified: new Date(),
    },
  });

  const daniel = await db.user.upsert({
    where: { email: "daniel.host@justwe.dev" },
    update: {},
    create: {
      email: "daniel.host@justwe.dev",
      passwordHash: await hash(PASSWORD),
      firstName: "Daniel",
      dateOfBirth: new Date("1988-09-02"),
      gender: "MALE",
      country: "NG",
      region: "Lagos",
      city: "Lagos",
      locationVisibility: "CITY_COUNTRY",
      bio: "Host of Africa Singles — a community for genuine, marriage-minded brothers and sisters.",
      profilePhotoUrl: PLACEHOLDER_PHOTO("daniel"),
      isHost: true,
      emailVerified: new Date(),
    },
  });

  await db.hostVerification.upsert({
    where: { userId: sarah.id },
    update: { status: "VERIFIED", reviewedBy: admin.id, reviewedAt: new Date() },
    create: { userId: sarah.id, status: "VERIFIED", reviewedBy: admin.id, reviewedAt: new Date() },
  });
  await db.hostVerification.upsert({
    where: { userId: daniel.id },
    update: { status: "PENDING" },
    create: { userId: daniel.id, status: "PENDING" },
  });

  // ---------- Communities ----------
  const worldwide = await db.community.upsert({
    where: { id: "seed-community-worldwide" },
    update: {},
    create: {
      id: "seed-community-worldwide",
      hostId: sarah.id,
      name: "Worldwide Singles Community",
      description:
        "A worldwide community for single brothers and sisters interested in serious relationships, wherever they live.",
      hostIntroduction: "I've hosted this community for two years and love seeing genuine connections form across the globe.",
      geographicFocus: "WORLDWIDE",
      imageUrl: PLACEHOLDER_PHOTO("worldwide-community"),
      visibility: "PUBLIC",
      rules: "Be respectful. Genuine intentions only. No solicitation or promotion. Treat every member with dignity.",
    },
  });

  const africaSingles = await db.community.upsert({
    where: { id: "seed-community-africa" },
    update: {},
    create: {
      id: "seed-community-africa",
      hostId: daniel.id,
      name: "Africa Singles",
      description: "A community rooted in Africa, open to genuine connections anywhere in the world.",
      geographicFocus: "AFRICA",
      imageUrl: PLACEHOLDER_PHOTO("africa-community"),
      visibility: "PUBLIC",
      rules: "Respectful conduct required. Serious relationship intentions only.",
    },
  });

  const finlandSingles = await db.community.upsert({
    where: { id: "seed-community-finland" },
    update: {},
    create: {
      id: "seed-community-finland",
      hostId: sarah.id,
      name: "Finland Singles",
      description: "A community with roots in Finland, welcoming members from anywhere.",
      geographicFocus: "COUNTRY",
      focusCountry: "FI",
      imageUrl: PLACEHOLDER_PHOTO("finland-community"),
      visibility: "PUBLIC",
      rules: "Kindness and honesty first.",
    },
  });

  // Host auto-memberships
  for (const [community, host] of [
    [worldwide, sarah],
    [africaSingles, daniel],
    [finlandSingles, sarah],
  ] as const) {
    await db.communityMembership.upsert({
      where: { communityId_userId: { communityId: community.id, userId: host.id } },
      update: {},
      create: { communityId: community.id, userId: host.id, status: "APPROVED", decidedAt: new Date(), decidedBy: host.id },
    });
  }

  // ---------- Members from multiple countries ----------
  type SeedMember = {
    email: string; firstName: string; gender: "MALE" | "FEMALE"; country: string; region?: string; city?: string;
    dob: string; bio: string; goals: string; ldPref: "YES" | "MAYBE" | "NO";
  };

  const memberDefs: SeedMember[] = [
    { email: "aino.member@justwe.dev", firstName: "Aino", gender: "FEMALE", country: "FI", region: "Central Finland", city: "Jyväskylä", dob: "1994-03-15", bio: "I enjoy hiking, reading, and deep conversations about faith and life.", goals: "Marriage within a few years", ldPref: "YES" },
    { email: "grace.member@justwe.dev", firstName: "Grace", gender: "FEMALE", country: "KE", region: "Nairobi County", city: "Nairobi", dob: "1993-07-22", bio: "Passionate about music and community service. Looking for a faithful, kind partner.", goals: "Marriage-minded", ldPref: "YES" },
    { email: "john.member@justwe.dev", firstName: "John", gender: "MALE", country: "KE", region: "Nairobi County", city: "Nairobi", dob: "1991-11-05", bio: "Enjoy football, cooking, and quiet evenings. Family means everything to me.", goals: "Marriage-minded", ldPref: "MAYBE" },
    { email: "emma.member@justwe.dev", firstName: "Emma", gender: "FEMALE", country: "US", region: "Texas", city: "Austin", dob: "1996-02-10", bio: "Nurse, coffee enthusiast, love travel and learning new languages.", goals: "Serious relationship leading to marriage", ldPref: "MAYBE" },
    { email: "michael.member@justwe.dev", firstName: "Michael", gender: "MALE", country: "GB", region: "England", city: "Manchester", dob: "1989-05-30", bio: "Engineer who loves cycling and volunteering.", goals: "Marriage-minded", ldPref: "NO" },
    { email: "abena.member@justwe.dev", firstName: "Abena", gender: "FEMALE", country: "GH", region: "Greater Accra", city: "Accra", dob: "1995-09-18", bio: "Teacher, love baking and gardening.", goals: "Marriage within two years", ldPref: "YES" },
    { email: "peter.member@justwe.dev", firstName: "Peter", gender: "MALE", country: "DE", region: "Bavaria", city: "Munich", dob: "1992-01-25", bio: "Software developer, enjoy hiking in the Alps.", goals: "Marriage-minded", ldPref: "MAYBE" },
    { email: "olivia.member@justwe.dev", firstName: "Olivia", gender: "FEMALE", country: "AU", region: "New South Wales", city: "Sydney", dob: "1994-12-08", bio: "Physiotherapist, love the outdoors and animals.", goals: "Serious relationship", ldPref: "MAYBE" },
  ];

  const members: Record<string, any> = {};
  for (const m of memberDefs) {
    const user = await db.user.upsert({
      where: { email: m.email },
      update: {},
      create: {
        email: m.email,
        passwordHash: await hash(PASSWORD),
        firstName: m.firstName,
        gender: m.gender,
        dateOfBirth: new Date(m.dob),
        country: m.country,
        region: m.region,
        city: m.city,
        locationVisibility: "REGION_COUNTRY",
        bio: m.bio,
        profilePhotoUrl: PLACEHOLDER_PHOTO(m.email),
        jwStatus: "BAPTIZED_PUBLISHER",
        spiritualGoals: "Growing in my relationship with Jehovah and looking for a spiritually strong partner.",
        relationshipGoals: m.goals,
        marriageIntention: "WHEN_RIGHT_PERSON_FOUND",
        longDistancePreference: m.ldPref,
        interests: ["Bible study", "Hiking", "Cooking", "Music"].slice(0, 2 + (m.firstName.length % 3)),
        languages: ["English"],
        datingProfileActive: true,
        datingIntentConfirmedAt: new Date(),
        emailVerified: new Date(),
      },
    });
    members[m.firstName] = user;

    // Each member gets 3 dating photos with seeded view counts.
    for (let i = 0; i < 3; i++) {
      await db.datingPhoto.create({
        data: {
          userId: user.id,
          imageUrl: PLACEHOLDER_PHOTO(`${m.email}-${i}`),
          displayOrder: i,
          viewCount: Math.floor(Math.random() * 150),
        },
      });
    }
  }

  // ---------- Memberships ----------
  // Everyone joins the Worldwide community (approved) — this is what enables
  // the long-distance Finland <-> Kenya connection below.
  const allMemberUsers = Object.values(members);
  for (const u of allMemberUsers) {
    await db.communityMembership.upsert({
      where: { communityId_userId: { communityId: worldwide.id, userId: (u as any).id } },
      update: {},
      create: { communityId: worldwide.id, userId: (u as any).id, status: "APPROVED", decidedAt: new Date(), decidedBy: sarah.id },
    });
  }

  // Kenyan + Ghanaian members also join Africa Singles.
  for (const name of ["Grace", "John", "Abena"]) {
    await db.communityMembership.upsert({
      where: { communityId_userId: { communityId: africaSingles.id, userId: members[name].id } },
      update: {},
      create: { communityId: africaSingles.id, userId: members[name].id, status: "APPROVED", decidedAt: new Date(), decidedBy: daniel.id },
    });
  }

  // Finnish member also joins Finland Singles.
  await db.communityMembership.upsert({
    where: { communityId_userId: { communityId: finlandSingles.id, userId: members["Aino"].id } },
    update: {},
    create: { communityId: finlandSingles.id, userId: members["Aino"].id, status: "APPROVED", decidedAt: new Date(), decidedBy: sarah.id },
  });

  // A pending join request awaiting host review.
  await db.communityMembership.upsert({
    where: { communityId_userId: { communityId: africaSingles.id, userId: members["Peter"].id } },
    update: { status: "PENDING", decidedAt: null, decidedBy: null },
    create: { communityId: africaSingles.id, userId: members["Peter"].id, status: "PENDING", introMessage: "Hi Daniel, I'd love to join your community." },
  });

  // ---------- Long-distance connection: Aino (Finland) <-> Grace (Kenya) ----------
  // Both are approved members of the Worldwide community, so they can discover
  // each other despite living on different continents — no distance filtering.
  await db.like.upsert({
    where: { fromUserId_toUserId_communityId: { fromUserId: members["Aino"].id, toUserId: members["Grace"].id, communityId: worldwide.id } },
    update: {},
    create: { fromUserId: members["Aino"].id, toUserId: members["Grace"].id, communityId: worldwide.id },
  });
  await db.like.upsert({
    where: { fromUserId_toUserId_communityId: { fromUserId: members["Grace"].id, toUserId: members["Aino"].id, communityId: worldwide.id } },
    update: {},
    create: { fromUserId: members["Grace"].id, toUserId: members["Aino"].id, communityId: worldwide.id },
  });

  const [firstId, secondId] = [members["Aino"].id, members["Grace"].id].sort();
  const longDistanceMatch = await db.match.upsert({
    where: { userAId_userBId_communityId: { userAId: firstId, userBId: secondId, communityId: worldwide.id } },
    update: {},
    create: { userAId: firstId, userBId: secondId, communityId: worldwide.id, status: "PENDING_HOST_REVIEW" },
  });

  for (const userId of [members["Aino"].id, members["Grace"].id]) {
    await db.notification.create({
      data: {
        userId,
        type: "MUTUAL_LIKE_PENDING",
        title: "You have a new update",
        body: "You have a new update regarding someone you expressed interest in. Your community host will review the connection before communication can begin.",
        metadata: { matchId: longDistanceMatch.id },
      },
    });
  }

  // ---------- A second, already-approved match with messages: John <-> Abena ----------
  await db.like.upsert({
    where: { fromUserId_toUserId_communityId: { fromUserId: members["John"].id, toUserId: members["Abena"].id, communityId: worldwide.id } },
    update: {},
    create: { fromUserId: members["John"].id, toUserId: members["Abena"].id, communityId: worldwide.id },
  });
  await db.like.upsert({
    where: { fromUserId_toUserId_communityId: { fromUserId: members["Abena"].id, toUserId: members["John"].id, communityId: worldwide.id } },
    update: {},
    create: { fromUserId: members["Abena"].id, toUserId: members["John"].id, communityId: worldwide.id },
  });

  const [a2, b2] = [members["John"].id, members["Abena"].id].sort();
  const approvedMatch = await db.match.upsert({
    where: { userAId_userBId_communityId: { userAId: a2, userBId: b2, communityId: worldwide.id } },
    update: { status: "APPROVED", reviewedBy: sarah.id, reviewedAt: new Date() },
    create: { userAId: a2, userBId: b2, communityId: worldwide.id, status: "APPROVED", reviewedBy: sarah.id, reviewedAt: new Date() },
  });

  await db.message.createMany({
    data: [
      { matchId: approvedMatch.id, senderId: members["John"].id, receiverId: members["Abena"].id, body: "Hi Abena! Really glad we got to connect. How are you doing today?" },
      { matchId: approvedMatch.id, senderId: members["Abena"].id, receiverId: members["John"].id, body: "Hi John! I'm doing well, thank you. Excited to get to know you better." },
      { matchId: approvedMatch.id, senderId: members["John"].id, receiverId: members["Abena"].id, body: "Likewise! What does a typical week look like for you?" },
    ],
  });

  for (const userId of [members["John"].id, members["Abena"].id]) {
    await db.notification.create({
      data: {
        userId,
        type: "MATCH_APPROVED",
        title: "Connection approved",
        body: "Your community host approved a connection. You can now get to know each other.",
        metadata: { matchId: approvedMatch.id },
      },
    });
  }

  // A rejected match example: Michael <-> Emma (kept anonymous to both)
  await db.like.upsert({
    where: { fromUserId_toUserId_communityId: { fromUserId: members["Michael"].id, toUserId: members["Emma"].id, communityId: worldwide.id } },
    update: {},
    create: { fromUserId: members["Michael"].id, toUserId: members["Emma"].id, communityId: worldwide.id },
  });
  await db.like.upsert({
    where: { fromUserId_toUserId_communityId: { fromUserId: members["Emma"].id, toUserId: members["Michael"].id, communityId: worldwide.id } },
    update: {},
    create: { fromUserId: members["Emma"].id, toUserId: members["Michael"].id, communityId: worldwide.id },
  });
  const [a3, b3] = [members["Michael"].id, members["Emma"].id].sort();
  await db.match.upsert({
    where: { userAId_userBId_communityId: { userAId: a3, userBId: b3, communityId: worldwide.id } },
    update: { status: "REJECTED", reviewedBy: sarah.id, reviewedAt: new Date() },
    create: { userAId: a3, userBId: b3, communityId: worldwide.id, status: "REJECTED", reviewedBy: sarah.id, reviewedAt: new Date() },
  });

  // ---------- Community posts ----------
  await db.communityPost.create({
    data: {
      communityId: worldwide.id,
      authorId: sarah.id,
      body: "Welcome to everyone who joined this week! Remember to review our community rules and reach out if you have any questions. 💚",
    },
  });
  await db.communityPost.create({
    data: {
      communityId: africaSingles.id,
      authorId: daniel.id,
      body: "Reminder: our community call is this Saturday. Looking forward to connecting with everyone!",
    },
  });

  console.log("Seed complete.");
  console.log("---------------------------------------------");
  console.log("Admin login:      admin@justwe.dev / " + PASSWORD);
  console.log("Verified host:    sarah.host@justwe.dev / " + PASSWORD);
  console.log("Unverified host:  daniel.host@justwe.dev / " + PASSWORD);
  console.log("Members:          <firstname-lowercase>.member@justwe.dev / " + PASSWORD);
  console.log("Long-distance example: Aino (Finland) <-> Grace (Kenya), pending host review");
  console.log("Approved match w/ messages: John (Kenya) <-> Abena (Ghana)");
  console.log("---------------------------------------------");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
