"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { COUNTRIES } from "@/lib/countries";
import { useToast } from "@/components/ui/ToastProvider";

export default function RegisterPage() {
  const router = useRouter();
  const { push } = useToast();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    firstName: "", email: "", password: "", dateOfBirth: "", country: "",
  });

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        push(data.error || "Something went wrong", "error");
        return;
      }
      push("Account created! Check your email to verify.", "success");
      router.push("/login?registered=1");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md card p-8 animate-slide-up">
        <Link href="/" className="font-serif text-2xl font-semibold text-forest-800 block text-center mb-2">
          Just<span className="text-brand-500">We</span>
        </Link>
        <h1 className="text-xl font-semibold text-center text-ink-800 mb-1">Create your account</h1>
        <p className="text-sm text-ink-400 text-center mb-6">Join a worldwide community of serious-minded singles.</p>

        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium text-ink-700">First name</label>
            <input
              required
              className="input mt-1"
              value={form.firstName}
              onChange={(e) => setForm({ ...form, firstName: e.target.value })}
            />
          </div>
          <div>
            <label className="text-sm font-medium text-ink-700">Email</label>
            <input
              required
              type="email"
              className="input mt-1"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
          </div>
          <div>
            <label className="text-sm font-medium text-ink-700">Password</label>
            <input
              required
              type="password"
              className="input mt-1"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
            <p className="text-xs text-ink-400 mt-1">At least 8 characters, one uppercase letter, one number.</p>
          </div>
          <div>
            <label className="text-sm font-medium text-ink-700">Date of birth</label>
            <input
              required
              type="date"
              className="input mt-1"
              value={form.dateOfBirth}
              onChange={(e) => setForm({ ...form, dateOfBirth: e.target.value })}
            />
            <p className="text-xs text-ink-400 mt-1">You must be 18 or older to use JustWe.</p>
          </div>
          <div>
            <label className="text-sm font-medium text-ink-700">Country</label>
            <select
              required
              className="input mt-1"
              value={form.country}
              onChange={(e) => setForm({ ...form, country: e.target.value })}
            >
              <option value="">Select your country</option>
              {COUNTRIES.map((c) => (
                <option key={c.code} value={c.code}>{c.name}</option>
              ))}
            </select>
          </div>

          <button disabled={loading} className="btn-primary w-full mt-2">
            {loading ? "Creating account…" : "Create Account"}
          </button>
        </form>

        <p className="text-sm text-center text-ink-400 mt-6">
          Already have an account? <Link href="/login" className="text-forest-700 font-medium">Log in</Link>
        </p>
      </div>
    </div>
  );
}
