"use client";

import { useEffect, useState } from "react";
import { TopNav } from "@/components/layout/TopNav";
import { useToast } from "@/components/ui/ToastProvider";
import { cn } from "@/lib/utils";

const TABS = ["Users", "Communities", "Reports"] as const;

export default function AdminPage() {
  const { push } = useToast();
  const [tab, setTab] = useState<typeof TABS[number]>("Users");
  const [users, setUsers] = useState<any[]>([]);
  const [communities, setCommunities] = useState<any[]>([]);
  const [reports, setReports] = useState<any[]>([]);

  async function loadUsers() { const r = await fetch("/api/admin/users"); if (r.ok) setUsers(await r.json()); }
  async function loadCommunities() { const r = await fetch("/api/admin/communities"); if (r.ok) setCommunities(await r.json()); }
  async function loadReports() { const r = await fetch("/api/admin/reports"); if (r.ok) setReports(await r.json()); }

  useEffect(() => { loadUsers(); loadCommunities(); loadReports(); }, []);

  async function suspend(userId: string, action: "SUSPEND" | "REINSTATE") {
    const r = await fetch(`/api/admin/users/${userId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action }) });
    if (r.ok) { push("Updated.", "success"); loadUsers(); }
  }

  async function verifyHost(userId: string, status: string) {
    const r = await fetch(`/api/admin/hosts/${userId}/verify`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) });
    if (r.ok) push("Host verification updated.", "success");
  }

  async function removeCommunity(id: string) {
    const r = await fetch(`/api/admin/communities/${id}`, { method: "DELETE" });
    if (r.ok) { push("Community removed.", "success"); loadCommunities(); }
  }

  async function updateReport(id: string, status: string) {
    const r = await fetch(`/api/admin/reports/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) });
    if (r.ok) { push("Report updated.", "success"); loadReports(); }
  }

  return (
    <div className="min-h-screen">
      <TopNav />
      <main className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="font-serif text-2xl font-semibold text-ink-800 mb-6">Admin</h1>
        <div className="flex gap-1 mb-6">
          {TABS.map((t) => (
            <button key={t} onClick={() => setTab(t)} className={cn("px-4 py-2 rounded-full text-sm font-medium", tab === t ? "bg-ink-800 text-white" : "bg-white border border-ink-100")}>
              {t}
            </button>
          ))}
        </div>

        {tab === "Users" && (
          <div className="space-y-2">
            {users.map((u) => (
              <div key={u.id} className="card p-4 flex items-center justify-between flex-wrap gap-2">
                <div>
                  <p className="font-medium text-ink-800 text-sm">{u.firstName} · {u.email}</p>
                  <p className="text-xs text-ink-400">{u.age} · {u.country} · {u.accountStatus} · {u.isHost ? "Host" : "Member"}</p>
                </div>
                <div className="flex gap-2">
                  {u.isHost && <button onClick={() => verifyHost(u.id, "VERIFIED")} className="text-xs text-forest-700 hover:underline">Verify host</button>}
                  {u.accountStatus === "ACTIVE" ? (
                    <button onClick={() => suspend(u.id, "SUSPEND")} className="text-xs text-brand-600 hover:underline">Suspend</button>
                  ) : (
                    <button onClick={() => suspend(u.id, "REINSTATE")} className="text-xs text-forest-700 hover:underline">Reinstate</button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "Communities" && (
          <div className="space-y-2">
            {communities.map((c) => (
              <div key={c.id} className="card p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-ink-800 text-sm">{c.name}</p>
                  <p className="text-xs text-ink-400">Hosted by {c.host.firstName} · {c._count.memberships} members</p>
                </div>
                <button onClick={() => removeCommunity(c.id)} className="text-xs text-brand-600 hover:underline">Remove</button>
              </div>
            ))}
          </div>
        )}

        {tab === "Reports" && (
          <div className="space-y-2">
            {reports.map((r) => (
              <div key={r.id} className="card p-4">
                <p className="text-sm text-ink-800">Report: {r.reason.replace("_", " ")} — status {r.status}</p>
                <p className="text-xs text-ink-400 mt-1">Against {r.reportedUser.firstName} ({r.reportedUser.email})</p>
                {r.details && <p className="text-sm text-ink-600 mt-1">{r.details}</p>}
                <div className="flex gap-2 mt-2">
                  <button onClick={() => updateReport(r.id, "REVIEWED")} className="text-xs text-forest-700 hover:underline">Mark reviewed</button>
                  <button onClick={() => updateReport(r.id, "DISMISSED")} className="text-xs text-ink-400 hover:underline">Dismiss</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
