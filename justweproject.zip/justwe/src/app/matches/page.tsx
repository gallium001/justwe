"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";
import { Clock, Heart } from "lucide-react";

type MatchItem = {
  id: string;
  status: "PENDING_HOST_REVIEW" | "APPROVED" | "REJECTED";
  createdAt: string;
  otherUser?: { id: string; firstName: string; profilePhotoUrl: string | null; age: number; location: string };
};

export default function MatchesPage() {
  const [matches, setMatches] = useState<MatchItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/matches").then((r) => r.json()).then((data) => setMatches(Array.isArray(data) ? data : [])).finally(() => setLoading(false));
  }, []);

  const approved = matches.filter((m) => m.status === "APPROVED");
  const pending = matches.filter((m) => m.status === "PENDING_HOST_REVIEW");

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <TopNav />
      <main className="max-w-2xl mx-auto px-4 py-8">
        <h1 className="font-serif text-2xl font-semibold text-ink-800 mb-6">Matches</h1>

        {loading ? (
          <div className="card h-32 animate-pulse bg-ink-50" />
        ) : matches.length === 0 ? (
          <div className="card p-8 text-center">
            <p className="text-ink-600">No approved connections yet.</p>
            <p className="text-sm text-ink-400 mt-1">When a mutual connection is approved by a host, you'll see it here.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {pending.length > 0 && (
              <section>
                <h2 className="text-sm font-medium text-ink-500 uppercase tracking-wide mb-2">Awaiting host review</h2>
                <div className="space-y-2">
                  {pending.map((m) => (
                    <div key={m.id} className="card p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-brand-50 flex items-center justify-center text-brand-500">
                        <Clock size={18} />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-ink-800">Connection awaiting host review</p>
                        <p className="text-xs text-ink-400">Since {new Date(m.createdAt).toLocaleDateString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {approved.length > 0 && (
              <section>
                <h2 className="text-sm font-medium text-ink-500 uppercase tracking-wide mb-2">Approved connections</h2>
                <div className="space-y-2">
                  {approved.map((m) => (
                    <Link key={m.id} href={`/matches/${m.id}`} className="card p-4 flex items-center gap-3 hover:shadow-soft">
                      <div className="w-12 h-12 rounded-full bg-forest-100 overflow-hidden flex items-center justify-center shrink-0">
                        {m.otherUser?.profilePhotoUrl ? (
                          <img src={m.otherUser.profilePhotoUrl} className="w-full h-full object-cover" alt="" />
                        ) : (
                          <Heart size={18} className="text-forest-500" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-ink-800">{m.otherUser?.firstName}, {m.otherUser?.age}</p>
                        <p className="text-xs text-ink-400">{m.otherUser?.location}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
}
