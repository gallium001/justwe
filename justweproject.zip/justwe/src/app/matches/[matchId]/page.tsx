"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";
import { ProfileGalleryModal } from "@/components/discover/ProfileGalleryModal";
import { Images, MessageCircle } from "lucide-react";

type MatchDetail = {
  id: string; status: string;
  otherUser?: { id: string; firstName: string; profilePhotoUrl: string | null; age: number; location: string; bio: string | null } | null;
};

export default function MatchDetailPage() {
  const { matchId } = useParams<{ matchId: string }>();
  const router = useRouter();
  const [match, setMatch] = useState<MatchDetail | null>(null);
  const [showGallery, setShowGallery] = useState(false);

  useEffect(() => {
    fetch(`/api/matches/${matchId}`).then((r) => r.json()).then(setMatch);
  }, [matchId]);

  if (!match) return <div className="min-h-screen"><TopNav /></div>;

  if (match.status !== "APPROVED" || !match.otherUser) {
    return (
      <div className="min-h-screen pb-20 md:pb-0">
        <TopNav />
        <main className="max-w-lg mx-auto px-4 py-16 text-center">
          <p className="text-ink-600">This connection isn't available.</p>
        </main>
        <BottomNav />
      </div>
    );
  }

  const other = match.otherUser;

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <TopNav />
      <main className="max-w-lg mx-auto px-4 py-8">
        <div className="card overflow-hidden">
          <div className="relative aspect-[4/5] bg-ink-100">
            {other.profilePhotoUrl ? (
              <img src={other.profilePhotoUrl} className="w-full h-full object-cover" alt={other.firstName} />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-6xl font-serif text-ink-300">{other.firstName[0]}</div>
            )}
            <button onClick={() => setShowGallery(true)} className="absolute bottom-3 right-3 bg-white/90 rounded-full px-3 py-1.5 text-xs font-medium flex items-center gap-1 text-ink-700">
              <Images size={14} /> View gallery
            </button>
          </div>
          <div className="p-5">
            <h1 className="text-xl font-semibold text-ink-800">{other.firstName}, {other.age}</h1>
            <p className="text-sm text-ink-400">{other.location}</p>
            {other.bio && <p className="text-ink-700 mt-3 text-sm">{other.bio}</p>}
            <button onClick={() => router.push(`/messages/${matchId}`)} className="btn-primary w-full mt-6 flex items-center justify-center gap-2">
              <MessageCircle size={18} /> Message {other.firstName}
            </button>
          </div>
        </div>
      </main>
      {showGallery && <ProfileGalleryModal userId={other.id} onClose={() => setShowGallery(false)} />}
      <BottomNav />
    </div>
  );
}
