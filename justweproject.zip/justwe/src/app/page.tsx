import Link from "next/link";
import { TopNav } from "@/components/layout/TopNav";
import { Users, Compass, ShieldCheck } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen">
      <TopNav />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-brand-gradient -z-10" />
        <div className="max-w-5xl mx-auto px-6 py-20 md:py-32 text-center">
          <span className="pill mb-6 inline-block">A worldwide community of serious-minded singles</span>
          <h1 className="font-serif text-4xl md:text-6xl font-semibold text-forest-900 leading-tight">
            Meet people through <br className="hidden md:block" /> trusted communities.
          </h1>
          <p className="mt-6 text-lg text-ink-600 max-w-2xl mx-auto">
            JustWe helps genuine people meet through private communities, trusted hosts, and meaningful
            connections — wherever they are in the world.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/register" className="btn-primary w-full sm:w-auto">
              Create Account
            </Link>
            <Link href="/communities" className="btn-outline w-full sm:w-auto">
              Explore Communities
            </Link>
          </div>
        </div>
      </section>

      {/* Three steps */}
      <section className="max-w-5xl mx-auto px-6 py-16 grid md:grid-cols-3 gap-8">
        <Step
          icon={<Users className="text-forest-600" size={28} />}
          num="1"
          title="Join a Community"
          body="Find a host and request to join their community."
        />
        <Step
          icon={<Compass className="text-brand-600" size={28} />}
          num="2"
          title="Meet People Anywhere"
          body="Discover eligible people in your communities, whether they live nearby or across the world."
        />
        <Step
          icon={<ShieldCheck className="text-forest-600" size={28} />}
          num="3"
          title="Connect with Approval"
          body="When two people express mutual interest, the community host reviews the connection before communication begins."
        />
      </section>

      {/* Values */}
      <section className="bg-forest-900 text-forest-50 py-16">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="font-serif text-2xl md:text-3xl font-semibold">Built for genuine connection, not endless scrolling</h2>
          <p className="mt-4 text-forest-100/80">
            No public swiping feed. No exposed likes. Every connection passes through a real host who knows
            their community — so mutual interest stays private until it's mutually approved.
          </p>
        </div>
      </section>

      <footer className="py-10 text-center text-sm text-ink-400">
        <p>© {new Date().getFullYear()} JustWe. A private, community-based platform.</p>
      </footer>
    </div>
  );
}

function Step({ icon, num, title, body }: { icon: React.ReactNode; num: string; title: string; body: string }) {
  return (
    <div className="card p-6 text-left">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-11 h-11 rounded-full bg-forest-50 flex items-center justify-center">{icon}</div>
        <span className="text-3xl font-serif text-ink-100 font-semibold">{num}</span>
      </div>
      <h3 className="font-semibold text-ink-800 text-lg">{title}</h3>
      <p className="text-ink-600 mt-1 text-sm">{body}</p>
    </div>
  );
}
