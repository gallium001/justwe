"use client";

import { useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { useToast } from "@/components/ui/ToastProvider";

export default function ResetPasswordPage() {
  const params = useSearchParams();
  const router = useRouter();
  const { push } = useToast();
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const token = params.get("token");
    if (!token) return push("Missing reset token", "error");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password }),
      });
      const data = await res.json();
      if (!res.ok) return push(data.error || "Reset failed", "error");
      push("Password updated. Please log in.", "success");
      router.push("/login");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md card p-8 animate-slide-up">
        <h1 className="text-xl font-semibold text-ink-800 mb-6">Set a new password</h1>
        <form onSubmit={onSubmit} className="space-y-4">
          <input
            required
            type="password"
            className="input"
            placeholder="New password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button disabled={loading} className="btn-primary w-full">{loading ? "Saving…" : "Save new password"}</button>
        </form>
      </div>
    </div>
  );
}
