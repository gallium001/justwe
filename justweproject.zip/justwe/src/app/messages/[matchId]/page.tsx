"use client";

import { useEffect, useRef, useState } from "react";
import { useParams } from "next/navigation";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";
import { Send } from "lucide-react";
import { cn } from "@/lib/utils";
import { useSession } from "next-auth/react";

type Message = { id: string; senderId: string; body: string; createdAt: string; readAt: string | null };

export default function ConversationPage() {
  const { matchId } = useParams<{ matchId: string }>();
  const { data: session } = useSession();
  const [messages, setMessages] = useState<Message[]>([]);
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  async function load() {
    const res = await fetch(`/api/messages/${matchId}`);
    if (res.ok) setMessages(await res.json());
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 5000);
    return () => clearInterval(interval);
  }, [matchId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!body.trim()) return;
    setSending(true);
    try {
      const res = await fetch(`/api/messages/${matchId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ body }),
      });
      if (res.ok) {
        setBody("");
        load();
      }
    } finally {
      setSending(false);
    }
  }

  const myId = (session?.user as any)?.id;

  return (
    <div className="min-h-screen pb-32 md:pb-0 flex flex-col">
      <TopNav />
      <main className="max-w-2xl mx-auto px-4 py-6 flex-1 flex flex-col w-full">
        <div className="flex-1 space-y-2 overflow-y-auto">
          {messages.map((m) => (
            <div key={m.id} className={cn("max-w-[75%] rounded-2xl px-4 py-2 text-sm", m.senderId === myId ? "ml-auto bg-brand-500 text-white" : "bg-white border border-ink-100 text-ink-800")}>
              {m.body}
              <div className={cn("text-[10px] mt-1", m.senderId === myId ? "text-white/70" : "text-ink-400")}>
                {new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        <form onSubmit={send} className="fixed md:sticky bottom-16 md:bottom-0 left-0 right-0 bg-white border-t border-ink-100 p-3 flex gap-2 max-w-2xl mx-auto w-full">
          <input className="input flex-1" placeholder="Write a message…" value={body} onChange={(e) => setBody(e.target.value)} />
          <button disabled={sending} className="btn-primary !px-4"><Send size={18} /></button>
        </form>
      </main>
      <BottomNav />
    </div>
  );
}
