"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";

type MatchItem = {
  id: string; status: string;
  otherUser?: { id: string; firstName: string; profilePhotoUrl: string | null };
};

export default function MessagesListPage() {
  const [matches, setMatches] = useState<MatchItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/matches").then((r) => r.json()).then((data) => {
      setMatches((Array.isArray(data) ? data : []).filter((m: MatchItem) => m.status === "APPROVED"));
    }).finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <TopNav />
      <main className="max-w-2xl mx-auto px-4 py-8">
        <h1 className="font-serif text-2xl font-semibold text-ink-800 mb-6">Messages</h1>
        {loading ? (
          <div className="card h-24 animate-pulse bg-ink-50" />
        ) : matches.length === 0 ? (
          <div className="card p-8 text-center text-ink-600">
            Messaging unlocks once a host approves a mutual connection.
          </div>
        ) : (
          <div className="space-y-2">
            {matches.map((m) => (
              <Link key={m.id} href={`/messages/${m.id}`} className="card p-4 flex items-center gap-3 hover:shadow-soft">
                <div className="w-11 h-11 rounded-full bg-forest-100 overflow-hidden flex items-center justify-center shrink-0">
                  {m.otherUser?.profilePhotoUrl ? (
                    <img src={m.otherUser.profilePhotoUrl} className="w-full h-full object-cover" alt="" />
                  ) : (
                    <span className="text-forest-600 font-semibold">{m.otherUser?.firstName?.[0]}</span>
                  )}
                </div>
                <p className="font-medium text-ink-800">{m.otherUser?.firstName}</p>
              </Link>
            ))}
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
}
