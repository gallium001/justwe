"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { TopNav } from "@/components/layout/TopNav";
import { useToast } from "@/components/ui/ToastProvider";

/**
 * Post-registration onboarding: choose account configuration (Dating / Host /
 * Both), matching spec §6. Hosting itself is set up via /host/create; here we
 * just route the person appropriately and, if they chose Dating, prompt the
 * genuine-intent confirmation before sending them to fill out their profile.
 */
export default function OnboardingPage() {
  const router = useRouter();
  const { push } = useToast();
  const [choice, setChoice] = useState<"DATING" | "HOST" | "BOTH" | null>(null);
  const [agree, setAgree] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function continueOnboarding() {
    if ((choice === "DATING" || choice === "BOTH") && !agree) {
      push("Please confirm your genuine intention to continue.", "error");
      return;
    }
    setSubmitting(true);
    try {
      if (choice === "DATING" || choice === "BOTH") {
        await fetch("/api/me/dating-activate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ agreesToGenuineIntent: true }),
        });
      }
      if (choice === "HOST") {
        router.push("/host/create");
      } else {
        router.push("/profile");
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen">
      <TopNav />
      <main className="max-w-lg mx-auto px-4 py-12">
        <h1 className="font-serif text-2xl font-semibold text-ink-800 mb-2 text-center">Welcome to JustWe</h1>
        <p className="text-ink-500 text-sm text-center mb-8">How would you like to use JustWe?</p>

        <div className="space-y-3 mb-6">
          {[
            { key: "DATING", title: "Dating Member", body: "Join communities and meet people for a serious relationship." },
            { key: "HOST", title: "Host", body: "Create and manage a community, and welcome new members." },
            { key: "BOTH", title: "Host + Dating Member", body: "Do both — host a community and have your own dating profile." },
          ].map((opt) => (
            <button
              key={opt.key}
              onClick={() => setChoice(opt.key as any)}
              className={`w-full text-left card p-5 border-2 transition-colors ${choice === opt.key ? "border-brand-500" : "border-transparent"}`}
            >
              <p className="font-medium text-ink-800">{opt.title}</p>
              <p className="text-sm text-ink-500 mt-0.5">{opt.body}</p>
            </button>
          ))}
        </div>

        {(choice === "DATING" || choice === "BOTH") && (
          <label className="flex gap-2 items-start text-sm text-ink-600 mb-6">
            <input type="checkbox" className="mt-1" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
            I confirm that I am genuinely interested in meeting someone for a serious relationship and that I am
            using JustWe for genuine dating purposes.
          </label>
        )}

        <button disabled={!choice || submitting} onClick={continueOnboarding} className="btn-primary w-full">
          {submitting ? "Setting up…" : "Continue"}
        </button>
      </main>
    </div>
  );
}
