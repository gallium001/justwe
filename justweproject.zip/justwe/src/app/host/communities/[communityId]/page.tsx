"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";
import { useToast } from "@/components/ui/ToastProvider";
import { cn } from "@/lib/utils";

type MemberRequest = {
  membershipId: string; status: string; requestedAt: string; introMessage: string | null;
  user: { id: string; firstName: string; age: number; gender: string | null; profilePhotoUrl: string | null; location: string; datingProfileActive: boolean; bio: string | null };
};

type HostMatch = {
  id: string; createdAt: string; community: { name: string };
  userA: any; userB: any;
};

const TABS = ["Join Requests", "Match Reviews", "Members", "Posts"] as const;

export default function HostCommunityPage() {
  const { communityId } = useParams<{ communityId: string }>();
  const { push } = useToast();
  const [tab, setTab] = useState<typeof TABS[number]>("Join Requests");

  const [requests, setRequests] = useState<MemberRequest[]>([]);
  const [members, setMembers] = useState<MemberRequest[]>([]);
  const [matches, setMatches] = useState<HostMatch[]>([]);
  const [posts, setPosts] = useState<any[]>([]);
  const [newPost, setNewPost] = useState("");

  async function loadRequests() {
    const res = await fetch(`/api/communities/${communityId}/members?status=PENDING`);
    if (res.ok) setRequests(await res.json());
  }
  async function loadMembers() {
    const res = await fetch(`/api/communities/${communityId}/members?status=APPROVED`);
    if (res.ok) setMembers(await res.json());
  }
  async function loadMatches() {
    const res = await fetch(`/api/host/matches`);
    if (res.ok) {
      const all = await res.json();
      setMatches(all.filter((m: HostMatch) => m.community.name && true).filter((m: any) => true));
    }
  }
  async function loadPosts() {
    const res = await fetch(`/api/communities/${communityId}/posts`);
    if (res.ok) setPosts(await res.json());
  }

  useEffect(() => {
    loadRequests(); loadMembers(); loadMatches(); loadPosts();
  }, [communityId]);

  async function decide(membershipId: string, action: "APPROVE" | "REJECT" | "REMOVE") {
    const res = await fetch(`/api/communities/${communityId}/members/${membershipId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action }),
    });
    if (res.ok) {
      push(action === "APPROVE" ? "Member approved." : action === "REJECT" ? "Request rejected." : "Member removed.", "success");
      loadRequests(); loadMembers();
    }
  }

  async function decideMatch(matchId: string, action: "APPROVE" | "REJECT") {
    const res = await fetch(`/api/host/matches/${matchId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action }),
    });
    if (res.ok) {
      push(action === "APPROVE" ? "Connection approved." : "Connection rejected.", "success");
      loadMatches();
    }
  }

  async function createPost(e: React.FormEvent) {
    e.preventDefault();
    if (!newPost.trim()) return;
    const res = await fetch(`/api/communities/${communityId}/posts`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ body: newPost }),
    });
    if (res.ok) { setNewPost(""); loadPosts(); }
  }

  const communityMatches = matches.filter((m) => true); // host/matches already scoped server-side to this host's communities

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <TopNav />
      <main className="max-w-3xl mx-auto px-4 py-8">
        <h1 className="font-serif text-2xl font-semibold text-ink-800 mb-6">Manage Community</h1>

        <div className="flex gap-1 mb-6 overflow-x-auto">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn("px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap", tab === t ? "bg-forest-700 text-white" : "bg-white border border-ink-100 text-ink-600")}
            >
              {t}
            </button>
          ))}
        </div>

        {tab === "Join Requests" && (
          <div className="space-y-3">
            {requests.length === 0 ? (
              <p className="text-ink-400 text-sm">No pending requests.</p>
            ) : (
              requests.map((r) => (
                <div key={r.membershipId} className="card p-4 flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full bg-forest-100 overflow-hidden flex items-center justify-center shrink-0">
                      {r.user.profilePhotoUrl ? <img src={r.user.profilePhotoUrl} className="w-full h-full object-cover" alt="" /> : <span className="font-semibold text-forest-600">{r.user.firstName[0]}</span>}
                    </div>
                    <div>
                      <p className="font-medium text-ink-800">{r.user.firstName}, {r.user.age} · {r.user.gender ?? "—"}</p>
                      <p className="text-xs text-ink-400">{r.user.location} · Requested {new Date(r.requestedAt).toLocaleDateString()}</p>
                      {r.introMessage && <p className="text-sm text-ink-600 mt-1">"{r.introMessage}"</p>}
                    </div>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <button onClick={() => decide(r.membershipId, "REJECT")} className="btn-outline !px-4 !py-2 text-sm">Reject</button>
                    <button onClick={() => decide(r.membershipId, "APPROVE")} className="btn-secondary !px-4 !py-2 text-sm">Approve</button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {tab === "Match Reviews" && (
          <div className="space-y-4">
            {communityMatches.length === 0 ? (
              <p className="text-ink-400 text-sm">No pending match reviews.</p>
            ) : (
              communityMatches.map((m) => (
                <div key={m.id} className="card p-5">
                  <p className="text-xs text-ink-400 mb-3">Potential Connection · {m.community.name}</p>
                  <div className="grid sm:grid-cols-2 gap-4">
                    {[m.userA, m.userB].map((u) => (
                      <div key={u.id} className="rounded-xl border border-ink-100 p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-9 h-9 rounded-full bg-forest-100 overflow-hidden flex items-center justify-center shrink-0">
                            {u.profilePhotoUrl ? <img src={u.profilePhotoUrl} className="w-full h-full object-cover" alt="" /> : <span className="text-forest-600 font-semibold text-sm">{u.firstName[0]}</span>}
                          </div>
                          <div>
                            <p className="font-medium text-ink-800 text-sm">{u.firstName}, {u.age}</p>
                            <p className="text-xs text-ink-400">{u.location}</p>
                          </div>
                        </div>
                        {u.bio && <p className="text-xs text-ink-600 mb-1">{u.bio}</p>}
                        {u.relationshipGoals && <p className="text-xs text-ink-500">Goals: {u.relationshipGoals}</p>}
                        {u.spiritualGoals && <p className="text-xs text-ink-500">Spiritual: {u.spiritualGoals}</p>}
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2 mt-4">
                    <button onClick={() => decideMatch(m.id, "REJECT")} className="btn-outline flex-1 text-sm">Reject Connection</button>
                    <button onClick={() => decideMatch(m.id, "APPROVE")} className="btn-secondary flex-1 text-sm">Approve Connection</button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {tab === "Members" && (
          <div className="space-y-2">
            {members.map((m) => (
              <div key={m.membershipId} className="card p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-forest-100 overflow-hidden flex items-center justify-center shrink-0">
                    {m.user.profilePhotoUrl ? <img src={m.user.profilePhotoUrl} className="w-full h-full object-cover" alt="" /> : <span className="text-forest-600 font-semibold text-sm">{m.user.firstName[0]}</span>}
                  </div>
                  <div>
                    <p className="font-medium text-ink-800 text-sm">{m.user.firstName}</p>
                    <p className="text-xs text-ink-400">{m.user.location}</p>
                  </div>
                </div>
                <button onClick={() => decide(m.membershipId, "REMOVE")} className="text-sm text-brand-600 hover:underline">Remove</button>
              </div>
            ))}
          </div>
        )}

        {tab === "Posts" && (
          <div>
            <form onSubmit={createPost} className="card p-4 mb-4 flex gap-2">
              <input className="input flex-1" placeholder="Share an update with your community…" value={newPost} onChange={(e) => setNewPost(e.target.value)} />
              <button className="btn-secondary">Post</button>
            </form>
            <div className="space-y-3">
              {posts.map((p) => (
                <div key={p.id} className="card p-4">
                  <p className="text-sm text-ink-800">{p.body}</p>
                  <p className="text-xs text-ink-400 mt-2">{new Date(p.createdAt).toLocaleString()}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
}
