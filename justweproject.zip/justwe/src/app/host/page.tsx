"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";
import { Users, Plus } from "lucide-react";

type Community = { id: string; name: string; memberCount?: number; imageUrl: string | null };

export default function HostOverviewPage() {
  const [communities, setCommunities] = useState<any[]>([]);

  useEffect(() => {
    // A host's own communities are listed among their approved memberships
    // (the create endpoint auto-approves the host). We filter client-side via /api/me + communities.
    fetch("/api/me/communities-approved").then((r) => r.json()).then(setCommunities).catch(() => {});
  }, []);

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <TopNav />
      <main className="max-w-3xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-serif text-2xl font-semibold text-ink-800">Host Dashboard</h1>
          <Link href="/host/create" className="btn-secondary text-sm flex items-center gap-1"><Plus size={16} /> New Community</Link>
        </div>

        {communities.length === 0 ? (
          <div className="card p-8 text-center text-ink-600">You don't host any communities yet.</div>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {communities.map((c) => (
              <Link key={c.id} href={`/host/communities/${c.id}`} className="card p-5 hover:shadow-soft flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-forest-100 flex items-center justify-center text-forest-600"><Users size={18} /></div>
                <div>
                  <p className="font-medium text-ink-800">{c.name}</p>
                  <p className="text-xs text-ink-400">Manage members, matches, and posts</p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
}
