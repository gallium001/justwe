"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";
import { useToast } from "@/components/ui/ToastProvider";
import { COUNTRIES } from "@/lib/countries";

export default function CreateCommunityPage() {
  const router = useRouter();
  const { push } = useToast();
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: "", description: "", hostIntroduction: "", geographicFocus: "WORLDWIDE",
    focusCountry: "", visibility: "PUBLIC", rules: "",
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch("/api/communities", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) return push(data.error || "Could not create community", "error");
      push("Community created!", "success");
      router.push(`/host/communities/${data.id}`);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <TopNav />
      <main className="max-w-xl mx-auto px-4 py-8">
        <h1 className="font-serif text-2xl font-semibold text-ink-800 mb-1">Create a Community</h1>
        <p className="text-ink-500 text-sm mb-6">You'll become the host and can review join requests and matches.</p>

        <form onSubmit={submit} className="card p-6 space-y-4">
          <div>
            <label className="text-sm font-medium text-ink-700">Community name</label>
            <input required className="input mt-1" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <label className="text-sm font-medium text-ink-700">Description</label>
            <textarea required className="input mt-1" rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
          <div>
            <label className="text-sm font-medium text-ink-700">Your introduction (shown on the community page)</label>
            <textarea className="input mt-1" rows={2} value={form.hostIntroduction} onChange={(e) => setForm({ ...form, hostIntroduction: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-ink-700">Geographic focus</label>
              <select className="input mt-1" value={form.geographicFocus} onChange={(e) => setForm({ ...form, geographicFocus: e.target.value })}>
                {["WORLDWIDE","AFRICA","EUROPE","NORTH_AMERICA","SOUTH_AMERICA","ASIA","OCEANIA","COUNTRY","REGION","CITY"].map((f) => (
                  <option key={f} value={f}>{f.replace("_", " ")}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-ink-700">Visibility</label>
              <select className="input mt-1" value={form.visibility} onChange={(e) => setForm({ ...form, visibility: e.target.value })}>
                <option value="PUBLIC">Public — discoverable</option>
                <option value="INVITE_ONLY">Invite-only</option>
              </select>
            </div>
          </div>
          {(form.geographicFocus === "COUNTRY") && (
            <div>
              <label className="text-sm font-medium text-ink-700">Focus country</label>
              <select className="input mt-1" value={form.focusCountry} onChange={(e) => setForm({ ...form, focusCountry: e.target.value })}>
                <option value="">Select…</option>
                {COUNTRIES.map((c) => <option key={c.code} value={c.code}>{c.name}</option>)}
              </select>
            </div>
          )}
          <div>
            <label className="text-sm font-medium text-ink-700">Community rules</label>
            <textarea required className="input mt-1" rows={4} value={form.rules} onChange={(e) => setForm({ ...form, rules: e.target.value })} placeholder="e.g. Be respectful. Genuine intentions only. No solicitation." />
          </div>
          <p className="text-xs text-ink-400">
            Note: geographic focus is descriptive only — it will not prevent members from other locations from joining or discovering each other.
          </p>
          <button disabled={saving} className="btn-secondary w-full">{saving ? "Creating…" : "Create Community"}</button>
        </form>
      </main>
      <BottomNav />
    </div>
  );
}
