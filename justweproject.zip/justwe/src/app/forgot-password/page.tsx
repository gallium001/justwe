"use client";

import { useState } from "react";
import Link from "next/link";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      setSent(true);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md card p-8 animate-slide-up">
        <h1 className="text-xl font-semibold text-ink-800 mb-2">Reset your password</h1>
        {sent ? (
          <p className="text-ink-600">If that email exists on JustWe, a reset link has been sent.</p>
        ) : (
          <form onSubmit={onSubmit} className="space-y-4">
            <p className="text-sm text-ink-500">Enter your email and we'll send you a reset link.</p>
            <input required type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            <button disabled={loading} className="btn-primary w-full">{loading ? "Sending…" : "Send reset link"}</button>
          </form>
        )}
        <p className="text-sm text-center text-ink-400 mt-6">
          <Link href="/login" className="text-forest-700 font-medium">Back to login</Link>
        </p>
      </div>
    </div>
  );
}
