"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";
import { ShieldCheck, Users, Search } from "lucide-react";

type CommunityCard = {
  id: string;
  name: string;
  description: string;
  imageUrl: string | null;
  geographicFocus: string;
  memberCount: number;
  rulesSummary: string;
  host: { id: string; firstName: string; profilePhotoUrl: string | null; location: string; verified: boolean };
};

export default function CommunitiesDiscoveryPage() {
  const [communities, setCommunities] = useState<CommunityCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");

  async function load(query = "") {
    setLoading(true);
    const res = await fetch(`/api/communities${query ? `?q=${encodeURIComponent(query)}` : ""}`);
    if (res.ok) setCommunities(await res.json());
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <TopNav />
      <main className="max-w-5xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
          <div>
            <h1 className="font-serif text-2xl md:text-3xl font-semibold text-ink-800">Find a Community</h1>
            <p className="text-ink-500 text-sm mt-1">Browse hosts and communities. Request to join to discover members.</p>
          </div>
          <Link href="/host/create" className="btn-secondary text-sm">Become a Host</Link>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            load(q);
          }}
          className="flex gap-2 mb-6"
        >
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" size={18} />
            <input
              className="input pl-10"
              placeholder="Search communities…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
          <button className="btn-outline">Search</button>
        </form>

        {loading ? (
          <div className="grid md:grid-cols-2 gap-5">
            {[1, 2, 3, 4].map((i) => <div key={i} className="card h-48 animate-pulse bg-ink-50" />)}
          </div>
        ) : communities.length === 0 ? (
          <div className="card p-10 text-center text-ink-500">No communities found. Try a different search.</div>
        ) : (
          <div className="grid md:grid-cols-2 gap-5">
            {communities.map((c) => (
              <Link key={c.id} href={`/communities/${c.id}`} className="card p-5 hover:shadow-soft transition-shadow block">
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-12 h-12 rounded-full bg-forest-100 overflow-hidden flex items-center justify-center shrink-0">
                    {c.host.profilePhotoUrl ? (
                      <img src={c.host.profilePhotoUrl} alt={c.host.firstName} className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-forest-600 font-semibold">{c.host.firstName[0]}</span>
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-medium text-ink-800">{c.host.firstName}</span>
                      {c.host.verified && (
                        <span className="badge-verified"><ShieldCheck size={12} /> Verified Host</span>
                      )}
                    </div>
                    <p className="text-xs text-ink-400">{c.host.location}</p>
                  </div>
                </div>
                <h3 className="font-serif text-lg font-semibold text-ink-800">{c.name}</h3>
                <p className="text-sm text-ink-600 mt-1 line-clamp-2">{c.description}</p>
                <div className="flex items-center justify-between mt-4">
                  <span className="pill"><Users size={14} className="inline mr-1" />{c.memberCount} members</span>
                  <span className="text-xs text-ink-400 uppercase tracking-wide">{c.geographicFocus.replace("_", " ")}</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
}
