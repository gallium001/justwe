"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";
import { ShieldCheck, Users } from "lucide-react";
import { useToast } from "@/components/ui/ToastProvider";
import { useSession } from "next-auth/react";

type CommunityDetail = {
  id: string; name: string; description: string; hostIntroduction: string | null;
  geographicFocus: string; imageUrl: string | null; rules: string; memberCount: number;
  host: { id: string; firstName: string; profilePhotoUrl: string | null; bio: string | null; location: string; verified: boolean };
  myMembershipStatus: string | null;
  isMine: boolean;
};

export default function CommunityDetailPage() {
  const { communityId } = useParams<{ communityId: string }>();
  const router = useRouter();
  const { data: session } = useSession();
  const { push } = useToast();
  const [community, setCommunity] = useState<CommunityDetail | null>(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [joining, setJoining] = useState(false);

  async function load() {
    const res = await fetch(`/api/communities/${communityId}`);
    if (res.ok) setCommunity(await res.json());
  }

  useEffect(() => { load(); }, [communityId]);

  async function requestToJoin() {
    if (!session) { router.push("/login"); return; }
    setJoining(true);
    try {
      const res = await fetch(`/api/communities/${communityId}/join`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
      const data = await res.json();
      if (!res.ok) return push(data.error || "Unable to send request", "error");
      push("Request sent! The host will review it.", "success");
      setShowConfirm(false);
      load();
    } finally {
      setJoining(false);
    }
  }

  if (!community) {
    return (
      <div className="min-h-screen">
        <TopNav />
        <div className="max-w-3xl mx-auto px-4 py-10 animate-pulse">
          <div className="h-40 bg-ink-50 rounded-xl2" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <TopNav />
      <main className="max-w-3xl mx-auto px-4 py-8">
        <div className="card p-6 md:p-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 rounded-full bg-forest-100 overflow-hidden flex items-center justify-center shrink-0">
              {community.host.profilePhotoUrl ? (
                <img src={community.host.profilePhotoUrl} className="w-full h-full object-cover" alt="" />
              ) : (
                <span className="text-forest-600 font-semibold text-xl">{community.host.firstName[0]}</span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-medium text-ink-800">Hosted by {community.host.firstName}</span>
                {community.host.verified && <span className="badge-verified"><ShieldCheck size={12}/> Verified Host</span>}
              </div>
              <p className="text-sm text-ink-400">{community.host.location}</p>
            </div>
          </div>

          <h1 className="font-serif text-2xl md:text-3xl font-semibold text-ink-800">{community.name}</h1>
          <div className="flex items-center gap-3 mt-2 mb-4">
            <span className="pill"><Users size={14} className="inline mr-1"/>{community.memberCount} members</span>
            <span className="text-xs text-ink-400 uppercase tracking-wide">{community.geographicFocus.replace("_", " ")}</span>
          </div>

          <p className="text-ink-700 leading-relaxed">{community.description}</p>

          {community.host.bio && (
            <div className="mt-5">
              <h3 className="font-medium text-ink-800 mb-1">About the host</h3>
              <p className="text-sm text-ink-600">{community.host.bio}</p>
            </div>
          )}

          <div className="mt-5">
            <h3 className="font-medium text-ink-800 mb-1">Community rules</h3>
            <p className="text-sm text-ink-600 whitespace-pre-line">{community.rules}</p>
          </div>

          <div className="mt-8">
            {community.isMine ? (
              <a href={`/host/communities/${community.id}`} className="btn-secondary w-full sm:w-auto">Manage as Host</a>
            ) : community.myMembershipStatus === "APPROVED" ? (
              <a href={`/discover?community=${community.id}`} className="btn-primary w-full sm:w-auto">Go to Discover</a>
            ) : community.myMembershipStatus === "PENDING" ? (
              <button disabled className="btn-outline w-full sm:w-auto">Request pending review</button>
            ) : community.myMembershipStatus === "REJECTED" ? (
              <p className="text-sm text-ink-400">Your previous request wasn't approved.</p>
            ) : (
              <button onClick={() => setShowConfirm(true)} className="btn-primary w-full sm:w-auto">Request to Join</button>
            )}
          </div>
        </div>
      </main>

      {showConfirm && (
        <div className="fixed inset-0 bg-ink-900/40 flex items-end sm:items-center justify-center z-50 p-4">
          <div className="card p-6 max-w-sm w-full animate-slide-up">
            <h2 className="font-semibold text-lg text-ink-800 mb-2">Request to join {community.name}?</h2>
            <p className="text-sm text-ink-600 mb-6">
              {community.host.firstName}, the community host, will review your request. By joining this community,
              you agree to respect its rules and use JustWe genuinely for its intended purpose.
            </p>
            <div className="flex gap-3">
              <button onClick={() => setShowConfirm(false)} className="btn-outline flex-1">Cancel</button>
              <button onClick={requestToJoin} disabled={joining} className="btn-primary flex-1">
                {joining ? "Sending…" : "Send Request"}
              </button>
            </div>
          </div>
        </div>
      )}
      <BottomNav />
    </div>
  );
}
