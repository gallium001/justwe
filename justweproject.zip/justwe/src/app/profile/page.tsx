"use client";

import { useEffect, useState } from "react";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";
import { useToast } from "@/components/ui/ToastProvider";
import { PhotoGalleryEditor } from "@/components/profile/PhotoGalleryEditor";
import { COUNTRIES } from "@/lib/countries";

type Me = {
  firstName: string; gender: string | null; country: string; region: string | null; city: string | null;
  locationVisibility: string; bio: string | null; jwStatus: string | null; spiritualGoals: string | null;
  lookingFor: string | null; relationshipGoals: string | null; marriageIntention: string | null;
  longDistancePreference: string; interests: string[]; languages: string[];
  datingProfileActive: boolean;
};

export default function ProfilePage() {
  const { push } = useToast();
  const [me, setMe] = useState<Me | null>(null);
  const [saving, setSaving] = useState(false);
  const [agree, setAgree] = useState(false);

  useEffect(() => {
    fetch("/api/me").then((r) => r.json()).then(setMe);
  }, []);

  async function save() {
    if (!me) return;
    setSaving(true);
    try {
      const res = await fetch("/api/me", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(me),
      });
      if (res.ok) push("Profile saved.", "success");
      else push("Could not save profile.", "error");
    } finally {
      setSaving(false);
    }
  }

  async function activateDating() {
    if (!agree) return push("Please confirm your genuine intention first.", "error");
    const res = await fetch("/api/me/dating-activate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ agreesToGenuineIntent: true }),
    });
    if (res.ok) {
      push("Dating profile activated!", "success");
      setMe((m) => (m ? { ...m, datingProfileActive: true } : m));
    } else {
      const data = await res.json();
      push(data.error || "Could not activate", "error");
    }
  }

  async function deactivateDating() {
    const res = await fetch("/api/me/dating-activate", { method: "DELETE" });
    if (res.ok) setMe((m) => (m ? { ...m, datingProfileActive: false } : m));
  }

  if (!me) return <div className="min-h-screen"><TopNav /></div>;

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <TopNav />
      <main className="max-w-2xl mx-auto px-4 py-8 space-y-8">
        <h1 className="font-serif text-2xl font-semibold text-ink-800">Your Profile</h1>

        <section className="card p-6">
          <h2 className="font-medium text-ink-800 mb-4">Photo Gallery</h2>
          <PhotoGalleryEditor />
        </section>

        <section className="card p-6">
          <h2 className="font-medium text-ink-800 mb-4">Dating Profile</h2>
          {me.datingProfileActive ? (
            <div className="flex items-center justify-between">
              <p className="text-sm text-forest-700">Your dating profile is active.</p>
              <button onClick={deactivateDating} className="text-sm text-ink-400 hover:text-brand-600">Deactivate</button>
            </div>
          ) : (
            <div className="space-y-3">
              <label className="flex gap-2 items-start text-sm text-ink-600">
                <input type="checkbox" className="mt-1" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
                I confirm that I am genuinely interested in meeting someone for a serious relationship and that I am
                using JustWe for genuine dating purposes.
              </label>
              <button onClick={activateDating} className="btn-primary">I agree — Activate my dating profile</button>
            </div>
          )}
        </section>

        <section className="card p-6 space-y-4">
          <h2 className="font-medium text-ink-800">Basics</h2>
          <div>
            <label className="text-sm font-medium text-ink-700">Bio</label>
            <textarea className="input mt-1" rows={3} value={me.bio || ""} onChange={(e) => setMe({ ...me, bio: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-ink-700">Gender</label>
              <select className="input mt-1" value={me.gender || ""} onChange={(e) => setMe({ ...me, gender: e.target.value })}>
                <option value="">—</option>
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-ink-700">Country</label>
              <select className="input mt-1" value={me.country} onChange={(e) => setMe({ ...me, country: e.target.value })}>
                {COUNTRIES.map((c) => <option key={c.code} value={c.code}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-ink-700">Region/State</label>
              <input className="input mt-1" value={me.region || ""} onChange={(e) => setMe({ ...me, region: e.target.value })} />
            </div>
            <div>
              <label className="text-sm font-medium text-ink-700">City</label>
              <input className="input mt-1" value={me.city || ""} onChange={(e) => setMe({ ...me, city: e.target.value })} />
            </div>
          </div>
          <div>
            <label className="text-sm font-medium text-ink-700">Location visible to others as</label>
            <select className="input mt-1" value={me.locationVisibility} onChange={(e) => setMe({ ...me, locationVisibility: e.target.value })}>
              <option value="COUNTRY_ONLY">Country only</option>
              <option value="REGION_COUNTRY">Region + Country</option>
              <option value="CITY_COUNTRY">City + Country</option>
            </select>
          </div>
        </section>

        <section className="card p-6 space-y-4">
          <h2 className="font-medium text-ink-800">Spiritual</h2>
          <div>
            <label className="text-sm font-medium text-ink-700">Jehovah's Witness status</label>
            <select className="input mt-1" value={me.jwStatus || ""} onChange={(e) => setMe({ ...me, jwStatus: e.target.value })}>
              <option value="">—</option>
              <option value="BAPTIZED_PUBLISHER">Baptized Publisher</option>
              <option value="UNBAPTIZED_PUBLISHER">Unbaptized Publisher</option>
              <option value="STUDENT">Bible Student</option>
              <option value="SYMPATHIZER">Sympathizer</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium text-ink-700">Spiritual goals</label>
            <textarea className="input mt-1" rows={2} value={me.spiritualGoals || ""} onChange={(e) => setMe({ ...me, spiritualGoals: e.target.value })} />
          </div>
        </section>

        <section className="card p-6 space-y-4">
          <h2 className="font-medium text-ink-800">Relationship</h2>
          <div>
            <label className="text-sm font-medium text-ink-700">What are you looking for?</label>
            <textarea className="input mt-1" rows={2} value={me.lookingFor || ""} onChange={(e) => setMe({ ...me, lookingFor: e.target.value })} />
          </div>
          <div>
            <label className="text-sm font-medium text-ink-700">Relationship goals</label>
            <input className="input mt-1" value={me.relationshipGoals || ""} onChange={(e) => setMe({ ...me, relationshipGoals: e.target.value })} />
          </div>
          <div>
            <label className="text-sm font-medium text-ink-700">Marriage intention</label>
            <select className="input mt-1" value={me.marriageIntention || ""} onChange={(e) => setMe({ ...me, marriageIntention: e.target.value })}>
              <option value="">—</option>
              <option value="WITHIN_A_YEAR">Within a year</option>
              <option value="ONE_TO_TWO_YEARS">One to two years</option>
              <option value="WHEN_RIGHT_PERSON_FOUND">When the right person is found</option>
              <option value="NOT_SURE_YET">Not sure yet</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium text-ink-700">Open to Long-Distance Relationships</label>
            <select className="input mt-1" value={me.longDistancePreference} onChange={(e) => setMe({ ...me, longDistancePreference: e.target.value })}>
              <option value="YES">Yes</option>
              <option value="MAYBE">Maybe</option>
              <option value="NO">No</option>
            </select>
          </div>
        </section>

        <button onClick={save} disabled={saving} className="btn-primary w-full">{saving ? "Saving…" : "Save Profile"}</button>
      </main>
      <BottomNav />
    </div>
  );
}
