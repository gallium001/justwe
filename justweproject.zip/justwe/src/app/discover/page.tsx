"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";
import { ProfileGalleryModal } from "@/components/discover/ProfileGalleryModal";
import { useToast } from "@/components/ui/ToastProvider";
import { Heart, X, Images } from "lucide-react";

type Community = { id: string; name: string };
type Profile = {
  id: string; firstName: string; age: number; gender: string | null; location: string; bio: string | null;
  profilePhotoUrl: string | null; jwStatus: string | null; spiritualGoals: string | null;
  relationshipGoals: string | null; marriageIntention: string | null; longDistancePreference: string;
  interests: string[]; languages: string[];
};

function DiscoverInner() {
  const searchParams = useSearchParams();
  const { push } = useToast();
  const [communities, setCommunities] = useState<Community[]>([]);
  const [communityId, setCommunityId] = useState<string>(searchParams.get("community") || "");
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [galleryUserId, setGalleryUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/me/communities-approved")
      .then((r) => (r.ok ? r.json() : []))
      .then((data) => {
        setCommunities(data);
        if (!communityId && data.length > 0) setCommunityId(data[0].id);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!communityId) { setLoading(false); return; }
    setLoading(true);
    fetch(`/api/communities/${communityId}/discover`)
      .then((r) => r.json())
      .then((data) => setProfiles(Array.isArray(data) ? data : []))
      .finally(() => setLoading(false));
  }, [communityId]);

  async function act(toUserId: string, action: "like" | "pass") {
    setProfiles((p) => p.filter((x) => x.id !== toUserId));
    if (action === "pass") return;
    const res = await fetch("/api/likes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ toUserId, communityId }),
    });
    if (res.ok) push("Interest sent.", "success");
  }

  const current = profiles[0];

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <TopNav />
      <main className="max-w-lg mx-auto px-4 py-8">
        <h1 className="font-serif text-2xl font-semibold text-ink-800 mb-1">Discover</h1>
        <p className="text-ink-500 text-sm mb-4">Eligible people from your communities — anywhere in the world.</p>

        {communities.length > 1 && (
          <select className="input mb-6" value={communityId} onChange={(e) => setCommunityId(e.target.value)}>
            {communities.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        )}

        {communities.length === 0 && !loading ? (
          <div className="card p-8 text-center">
            <p className="text-ink-600">You're not part of a community yet.</p>
            <p className="text-sm text-ink-400 mt-1">Find a community and request to join before discovering people.</p>
            <a href="/communities" className="btn-primary mt-4 inline-block">Find a Community</a>
          </div>
        ) : loading ? (
          <div className="card h-[480px] animate-pulse bg-ink-50" />
        ) : !current ? (
          <div className="card p-8 text-center">
            <p className="text-ink-600">No new people to discover right now.</p>
            <p className="text-sm text-ink-400 mt-1">Check back later or join another community.</p>
          </div>
        ) : (
          <div className="card overflow-hidden animate-fade-in">
            <div className="relative aspect-[4/5] bg-ink-100">
              {current.profilePhotoUrl ? (
                <img src={current.profilePhotoUrl} className="w-full h-full object-cover" alt={current.firstName} />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-ink-300 text-6xl font-serif">
                  {current.firstName[0]}
                </div>
              )}
              <button
                onClick={() => setGalleryUserId(current.id)}
                className="absolute bottom-3 right-3 bg-white/90 rounded-full px-3 py-1.5 text-xs font-medium flex items-center gap-1 text-ink-700"
              >
                <Images size={14} /> View gallery
              </button>
            </div>
            <div className="p-5">
              <h2 className="text-xl font-semibold text-ink-800">{current.firstName}, {current.age}</h2>
              <p className="text-sm text-ink-400">{current.location}</p>
              {current.bio && <p className="text-ink-700 mt-3 text-sm">{current.bio}</p>}

              <div className="flex flex-wrap gap-2 mt-3">
                {current.relationshipGoals && <span className="pill">{current.relationshipGoals}</span>}
                {current.longDistancePreference && (
                  <span className="pill">Long-distance: {current.longDistancePreference.toLowerCase()}</span>
                )}
              </div>

              {current.interests?.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {current.interests.map((i) => <span key={i} className="text-xs bg-brand-50 text-brand-700 rounded-full px-2.5 py-1">{i}</span>)}
                </div>
              )}

              <div className="flex gap-4 mt-6">
                <button onClick={() => act(current.id, "pass")} className="flex-1 rounded-full border-2 border-ink-100 py-3 flex items-center justify-center text-ink-500 hover:bg-ink-50">
                  <X size={22} />
                </button>
                <button onClick={() => act(current.id, "like")} className="flex-1 rounded-full bg-brand-500 hover:bg-brand-600 py-3 flex items-center justify-center text-white">
                  <Heart size={22} />
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
      {galleryUserId && <ProfileGalleryModal userId={galleryUserId} onClose={() => setGalleryUserId(null)} />}
      <BottomNav />
    </div>
  );
}

export default function DiscoverPage() {
  return (
    <Suspense fallback={null}>
      <DiscoverInner />
    </Suspense>
  );
}
