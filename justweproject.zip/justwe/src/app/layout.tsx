import type { Metadata } from "next";
import "./globals.css";
import { AuthProvider } from "@/components/providers/AuthProvider";
import { ToastProviderInternal } from "@/components/ui/ToastProvider";

export const metadata: Metadata = {
  title: "JustWe — Meet people through trusted communities",
  description:
    "JustWe helps genuine people meet through private communities, trusted hosts, and meaningful connections — wherever they are in the world.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <AuthProvider>
          <ToastProviderInternal>{children}</ToastProviderInternal>
        </AuthProvider>
      </body>
    </html>
  );
}
