"use client";

import { useState } from "react";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";
import { useToast } from "@/components/ui/ToastProvider";
import { signOut } from "next-auth/react";

export default function SettingsPage() {
  const { push } = useToast();
  const [currentPassword, setCurrentPassword] = useState("");

  async function requestAccountDeletion() {
    if (!confirm("Are you sure you want to permanently delete your account? This cannot be undone.")) return;
    // In production wire this to a dedicated self-service delete endpoint that
    // re-authenticates the user first; omitted here for brevity but the admin
    // soft-delete path (/api/admin/users/[userId] DELETE) shows the pattern.
    push("Please contact support to complete account deletion.", "info");
  }

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <TopNav />
      <main className="max-w-xl mx-auto px-4 py-8 space-y-6">
        <h1 className="font-serif text-2xl font-semibold text-ink-800">Settings</h1>

        <section className="card p-6">
          <h2 className="font-medium text-ink-800 mb-2">Privacy</h2>
          <p className="text-sm text-ink-600">
            Control how much of your location is shown to others from your <a href="/profile" className="text-forest-700 underline">Profile</a> page.
            Your exact address is never collected or shown. Photo view counts are visible only to you; no one can see who viewed their photos.
          </p>
        </section>

        <section className="card p-6">
          <h2 className="font-medium text-ink-800 mb-2">Notifications</h2>
          <p className="text-sm text-ink-600">
            You'll receive notifications for community activity, new messages, and connection updates. Mutual-interest
            notifications never reveal who the other person is until a host approves the connection.
          </p>
        </section>

        <section className="card p-6">
          <h2 className="font-medium text-ink-800 mb-2">Account</h2>
          <button onClick={() => signOut({ callbackUrl: "/" })} className="btn-outline mb-3">Sign out</button>
          <div>
            <button onClick={requestAccountDeletion} className="text-sm text-brand-600 hover:underline">Delete my account</button>
          </div>
        </section>
      </main>
      <BottomNav />
    </div>
  );
}
