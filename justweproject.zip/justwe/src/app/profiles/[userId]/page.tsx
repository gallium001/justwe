"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { TopNav } from "@/components/layout/TopNav";
import { BottomNav } from "@/components/layout/BottomNav";
import { ProfileGalleryModal } from "@/components/discover/ProfileGalleryModal";
import { useToast } from "@/components/ui/ToastProvider";
import { Images, Flag, ShieldOff } from "lucide-react";

type Profile = {
  id: string; firstName: string; age: number; location: string; bio: string | null; profilePhotoUrl: string | null;
  jwStatus: string | null; spiritualGoals: string | null; lookingFor: string | null; relationshipGoals: string | null;
  marriageIntention: string | null; longDistancePreference: string; interests: string[]; languages: string[];
};

const REPORT_REASONS = ["FAKE_PROFILE", "HARASSMENT", "INAPPROPRIATE_BEHAVIOR", "MISREPRESENTATION", "SPAM", "OTHER"];

export default function PublicProfilePage() {
  const { userId } = useParams<{ userId: string }>();
  const { push } = useToast();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [showGallery, setShowGallery] = useState(false);
  const [showReport, setShowReport] = useState(false);

  useEffect(() => {
    fetch(`/api/profiles/${userId}`).then((r) => (r.ok ? r.json() : null)).then(setProfile);
  }, [userId]);

  async function block() {
    const res = await fetch("/api/block", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ blockedId: userId }) });
    if (res.ok) push("User blocked.", "success");
  }

  async function report(reason: string) {
    const res = await fetch("/api/report", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ reportedUserId: userId, reason }) });
    if (res.ok) { push("Report submitted.", "success"); setShowReport(false); }
  }

  if (!profile) return <div className="min-h-screen"><TopNav /><p className="text-center py-20 text-ink-400">This profile isn't available to you.</p></div>;

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <TopNav />
      <main className="max-w-lg mx-auto px-4 py-8">
        <div className="card overflow-hidden">
          <div className="relative aspect-[4/5] bg-ink-100">
            {profile.profilePhotoUrl ? (
              <img src={profile.profilePhotoUrl} className="w-full h-full object-cover" alt={profile.firstName} />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-6xl font-serif text-ink-300">{profile.firstName[0]}</div>
            )}
            <button onClick={() => setShowGallery(true)} className="absolute bottom-3 right-3 bg-white/90 rounded-full px-3 py-1.5 text-xs font-medium flex items-center gap-1 text-ink-700">
              <Images size={14} /> View gallery
            </button>
          </div>
          <div className="p-5">
            <h1 className="text-xl font-semibold text-ink-800">{profile.firstName}, {profile.age}</h1>
            <p className="text-sm text-ink-400">{profile.location}</p>
            {profile.bio && <p className="text-ink-700 mt-3 text-sm">{profile.bio}</p>}

            <div className="flex gap-4 mt-6 pt-4 border-t border-ink-100">
              <button onClick={() => setShowReport(true)} className="text-sm text-ink-400 hover:text-brand-600 flex items-center gap-1"><Flag size={14}/> Report</button>
              <button onClick={block} className="text-sm text-ink-400 hover:text-brand-600 flex items-center gap-1"><ShieldOff size={14}/> Block</button>
            </div>
          </div>
        </div>
      </main>

      {showReport && (
        <div className="fixed inset-0 bg-ink-900/40 flex items-end sm:items-center justify-center z-50 p-4">
          <div className="card p-6 max-w-sm w-full">
            <h2 className="font-semibold text-ink-800 mb-3">Report this profile</h2>
            <div className="space-y-2">
              {REPORT_REASONS.map((r) => (
                <button key={r} onClick={() => report(r)} className="w-full text-left text-sm px-3 py-2 rounded-lg hover:bg-ink-50">
                  {r.replace(/_/g, " ").toLowerCase()}
                </button>
              ))}
            </div>
            <button onClick={() => setShowReport(false)} className="text-xs text-ink-400 mt-3">Cancel</button>
          </div>
        </div>
      )}

      {showGallery && <ProfileGalleryModal userId={profile.id} onClose={() => setShowGallery(false)} />}
      <BottomNav />
    </div>
  );
}
