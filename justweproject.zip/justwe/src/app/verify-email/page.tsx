"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";

export default function VerifyEmailPage() {
  const params = useSearchParams();
  const [status, setStatus] = useState<"loading" | "ok" | "error">("loading");

  useEffect(() => {
    const token = params.get("token");
    if (!token) {
      setStatus("error");
      return;
    }
    fetch("/api/auth/verify-email", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token }),
    })
      .then((res) => setStatus(res.ok ? "ok" : "error"))
      .catch(() => setStatus("error"));
  }, [params]);

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="card p-8 max-w-md text-center animate-fade-in">
        {status === "loading" && <p className="text-ink-600">Verifying your email…</p>}
        {status === "ok" && (
          <>
            <h1 className="text-xl font-semibold text-forest-700 mb-2">Email verified</h1>
            <p className="text-ink-600 mb-6">Your account is ready. You can now log in.</p>
            <Link href="/login" className="btn-primary">Log In</Link>
          </>
        )}
        {status === "error" && (
          <>
            <h1 className="text-xl font-semibold text-brand-600 mb-2">Link invalid or expired</h1>
            <p className="text-ink-600 mb-6">Please request a new verification email or contact support.</p>
            <Link href="/login" className="btn-outline">Back to login</Link>
          </>
        )}
      </div>
    </div>
  );
}
