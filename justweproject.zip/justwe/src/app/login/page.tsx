"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { useToast } from "@/components/ui/ToastProvider";

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const { push } = useToast();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await signIn("credentials", { email, password, redirect: false });
      if (res?.error) {
        if (res.error === "EMAIL_NOT_VERIFIED") {
          push("Please verify your email before logging in.", "error");
        } else {
          push("Invalid email or password.", "error");
        }
        return;
      }
      router.push("/communities");
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md card p-8 animate-slide-up">
        <Link href="/" className="font-serif text-2xl font-semibold text-forest-800 block text-center mb-2">
          Just<span className="text-brand-500">We</span>
        </Link>
        <h1 className="text-xl font-semibold text-center text-ink-800 mb-6">Welcome back</h1>

        {params.get("registered") && (
          <div className="bg-forest-50 text-forest-700 text-sm rounded-lg p-3 mb-4">
            Check your inbox for a verification link before logging in.
          </div>
        )}

        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium text-ink-700">Email</label>
            <input required type="email" className="input mt-1" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label className="text-sm font-medium text-ink-700">Password</label>
            <input required type="password" className="input mt-1" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <div className="text-right">
            <Link href="/forgot-password" className="text-sm text-forest-700">Forgot password?</Link>
          </div>
          <button disabled={loading} className="btn-primary w-full">
            {loading ? "Signing in…" : "Log In"}
          </button>
        </form>

        <p className="text-sm text-center text-ink-400 mt-6">
          New to JustWe? <Link href="/register" className="text-forest-700 font-medium">Create an account</Link>
        </p>
      </div>
    </div>
  );
}
