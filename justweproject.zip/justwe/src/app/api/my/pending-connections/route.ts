import { requireUser } from "@/lib/session";
import { db } from "@/lib/db";
import { apiOk, handleApiError } from "@/lib/utils";

/**
 * GET /api/my/pending-connections
 * Returns ONLY status + timestamp for the current user's pending matches.
 * Deliberately mirrors spec §66's exact shape — no otherUserId, name, or photo.
 */
export async function GET() {
  try {
    const user = await requireUser();

    const matches = await db.match.findMany({
      where: {
        status: "PENDING_HOST_REVIEW",
        OR: [{ userAId: user.id }, { userBId: user.id }],
      },
      select: { id: true, status: true, createdAt: true },
      orderBy: { createdAt: "desc" },
    });

    const anonymized = matches.map((m) => ({
      id: m.id,
      status: "pending_host_review" as const,
      createdAt: m.createdAt,
    }));

    return apiOk(anonymized);
  } catch (err) {
    return handleApiError(err);
  }
}
