import { requireUser } from "@/lib/session";
import { db } from "@/lib/db";
import { apiOk, handleApiError } from "@/lib/utils";

/** Communities where the current user has APPROVED membership — powers the Discover community switcher. */
export async function GET() {
  try {
    const user = await requireUser();
    const memberships = await db.communityMembership.findMany({
      where: { userId: user.id, status: "APPROVED" },
      include: { community: { select: { id: true, name: true, imageUrl: true } } },
      orderBy: { decidedAt: "desc" },
    });
    return apiOk(memberships.map((m) => m.community));
  } catch (err) {
    return handleApiError(err);
  }
}
