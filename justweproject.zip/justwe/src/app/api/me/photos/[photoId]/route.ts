import { NextRequest } from "next/server";
import { requireUser, ForbiddenError } from "@/lib/session";
import { db } from "@/lib/db";
import { apiOk, handleApiError } from "@/lib/utils";
import { deleteObject, keyFromPublicUrl } from "@/lib/storage";

async function assertOwnership(userId: string, photoId: string) {
  const photo = await db.datingPhoto.findUnique({ where: { id: photoId } });
  if (!photo || photo.userId !== userId) throw new ForbiddenError("Photo not found");
  return photo;
}

export async function PATCH(req: NextRequest, { params }: { params: { photoId: string } }) {
  try {
    const user = await requireUser();
    await assertOwnership(user.id, params.photoId);
    const { displayOrder } = await req.json();

    const updated = await db.datingPhoto.update({
      where: { id: params.photoId },
      data: { displayOrder },
    });
    return apiOk(updated);
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { photoId: string } }) {
  try {
    const user = await requireUser();
    const photo = await assertOwnership(user.id, params.photoId);

    await db.datingPhoto.delete({ where: { id: params.photoId } });

    const key = keyFromPublicUrl(photo.imageUrl);
    if (key) await deleteObject(key).catch(() => {});

    return apiOk({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
