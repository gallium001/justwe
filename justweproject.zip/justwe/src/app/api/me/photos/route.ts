import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { db } from "@/lib/db";
import { photoUploadSchema } from "@/lib/validators";
import { apiOk, apiError, handleApiError } from "@/lib/utils";
import { MAX_PHOTOS_PER_USER } from "@/lib/storage";

export async function GET() {
  try {
    const user = await requireUser();
    const photos = await db.datingPhoto.findMany({
      where: { userId: user.id },
      orderBy: { displayOrder: "asc" },
      // viewCount is the only engagement metric ever returned — no viewer identities.
      select: { id: true, imageUrl: true, thumbnailUrl: true, displayOrder: true, viewCount: true, createdAt: true },
    });
    return apiOk(photos);
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const data = photoUploadSchema.parse(await req.json());

    const count = await db.datingPhoto.count({ where: { userId: user.id } });
    if (count >= MAX_PHOTOS_PER_USER) {
      return apiError(`You can upload up to ${MAX_PHOTOS_PER_USER} photos`, 422);
    }

    const photo = await db.datingPhoto.create({
      data: {
        userId: user.id,
        imageUrl: data.imageUrl,
        thumbnailUrl: data.thumbnailUrl,
        displayOrder: data.displayOrder ?? count,
      },
    });

    // First photo uploaded also becomes the headline profile photo if none is set.
    if (!user.profilePhotoUrl) {
      await db.user.update({ where: { id: user.id }, data: { profilePhotoUrl: data.imageUrl } });
    }

    return apiOk(photo, 201);
  } catch (err) {
    return handleApiError(err);
  }
}
