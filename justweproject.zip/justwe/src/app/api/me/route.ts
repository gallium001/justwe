import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { db } from "@/lib/db";
import { profileUpdateSchema } from "@/lib/validators";
import { apiOk, handleApiError } from "@/lib/utils";

export async function GET() {
  try {
    const user = await requireUser();
    // Full self-view is fine — a user may see their own sensitive fields.
    const { passwordHash, ...safe } = user;
    return apiOk(safe);
  } catch (err) {
    return handleApiError(err);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const user = await requireUser();
    const data = profileUpdateSchema.parse(await req.json());

    const updated = await db.user.update({
      where: { id: user.id },
      data,
    });

    const { passwordHash, ...safe } = updated;
    return apiOk(safe);
  } catch (err) {
    return handleApiError(err);
  }
}
