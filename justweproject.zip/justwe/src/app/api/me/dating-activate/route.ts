import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { db } from "@/lib/db";
import { activateDatingSchema } from "@/lib/validators";
import { apiOk, apiError, handleApiError, calculateAge, MIN_DATING_AGE } from "@/lib/utils";

/** Activate the dating profile. Requires explicit confirmation checkbox (spec §14) and 18+ (spec §53). */
export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    activateDatingSchema.parse(await req.json());

    if (calculateAge(user.dateOfBirth) < MIN_DATING_AGE) {
      return apiError("You must be 18 or older to activate a dating profile", 403);
    }

    const updated = await db.user.update({
      where: { id: user.id },
      data: { datingProfileActive: true, datingIntentConfirmedAt: new Date() },
    });

    const { passwordHash, ...safe } = updated;
    return apiOk(safe);
  } catch (err) {
    return handleApiError(err);
  }
}

/** Deactivate the dating profile — always allowed, no confirmation needed. */
export async function DELETE() {
  try {
    const user = await requireUser();
    const updated = await db.user.update({
      where: { id: user.id },
      data: { datingProfileActive: false },
    });
    const { passwordHash, ...safe } = updated;
    return apiOk(safe);
  } catch (err) {
    return handleApiError(err);
  }
}
