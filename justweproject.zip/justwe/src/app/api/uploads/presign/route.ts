import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { apiOk, apiError, handleApiError } from "@/lib/utils";
import { createPresignedUpload, ALLOWED_IMAGE_TYPES, MAX_IMAGE_BYTES } from "@/lib/storage";
import { checkRateLimit } from "@/lib/rate-limit";

const FOLDERS = ["dating-photos", "community-images", "profile-photos", "post-images"] as const;

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const { allowed } = checkRateLimit("uploads:presign", user.id, 30, 60_000);
    if (!allowed) return apiError("Too many upload requests. Please slow down.", 429);

    const { folder, contentType, fileSize } = await req.json();

    if (!FOLDERS.includes(folder)) return apiError("Invalid upload folder", 422);
    if (!ALLOWED_IMAGE_TYPES.includes(contentType)) return apiError("Only JPEG, PNG, or WEBP images are allowed", 422);
    if (typeof fileSize === "number" && fileSize > MAX_IMAGE_BYTES) return apiError("Image is too large (max 8MB)", 422);

    // community-images uploads are still namespaced by userId; server-side host
    // check happens when the community is actually created/updated with the URL.
    const result = await createPresignedUpload({ userId: user.id, folder, contentType });
    return apiOk(result);
  } catch (err) {
    return handleApiError(err);
  }
}
