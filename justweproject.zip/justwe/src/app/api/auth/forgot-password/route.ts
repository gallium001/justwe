import { NextRequest } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { forgotPasswordSchema } from "@/lib/validators";
import { apiOk, apiError, handleApiError } from "@/lib/utils";
import { sendPasswordResetEmail } from "@/lib/email";
import { checkRateLimit } from "@/lib/rate-limit";

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "unknown";
    const { allowed } = checkRateLimit("forgot-password", ip, 5, 60_000);
    if (!allowed) return apiError("Too many attempts. Please try again shortly.", 429);

    const { email } = forgotPasswordSchema.parse(await req.json());
    const user = await db.user.findUnique({ where: { email: email.toLowerCase() } });

    // Always respond identically whether or not the account exists (prevents enumeration).
    if (user) {
      const rawToken = crypto.randomBytes(32).toString("hex");
      const tokenHash = crypto.createHash("sha256").update(rawToken).digest("hex");
      await db.passwordResetToken.create({
        data: { userId: user.id, tokenHash, expiresAt: new Date(Date.now() + 60 * 60 * 1000) },
      });
      await sendPasswordResetEmail(user.email, user.firstName, rawToken);
    }

    return apiOk({ ok: true, message: "If that email exists, a reset link has been sent." });
  } catch (err) {
    return handleApiError(err);
  }
}
