import { NextRequest } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { apiError, apiOk, handleApiError } from "@/lib/utils";

export async function POST(req: NextRequest) {
  try {
    const { token } = await req.json();
    if (!token || typeof token !== "string") return apiError("Invalid token", 422);

    const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
    const record = await db.emailVerificationToken.findUnique({ where: { tokenHash } });

    if (!record || record.usedAt || record.expiresAt < new Date()) {
      return apiError("This verification link is invalid or has expired", 400);
    }

    await db.$transaction([
      db.user.update({ where: { id: record.userId }, data: { emailVerified: new Date() } }),
      db.emailVerificationToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
    ]);

    return apiOk({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
