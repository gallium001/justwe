import { NextRequest } from "next/server";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { db } from "@/lib/db";
import { registerSchema, MIN_AGE } from "@/lib/validators";
import { apiError, apiOk, handleApiError, calculateAge } from "@/lib/utils";
import { sendVerificationEmail } from "@/lib/email";
import { checkRateLimit } from "@/lib/rate-limit";

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "unknown";
    const { allowed } = checkRateLimit("register", ip, 8, 60_000);
    if (!allowed) return apiError("Too many attempts. Please try again shortly.", 429);

    const body = await req.json();
    const data = registerSchema.parse(body);

    // Server-side age enforcement — never trust client-side date math (spec §53).
    const age = calculateAge(data.dateOfBirth);
    if (age < MIN_AGE) {
      return apiError(`You must be at least ${MIN_AGE} years old to use JustWe`, 422);
    }

    const email = data.email.toLowerCase().trim();
    const existing = await db.user.findUnique({ where: { email } });
    if (existing) {
      return apiError("An account with this email already exists", 409);
    }

    const passwordHash = await bcrypt.hash(data.password, 12);

    const user = await db.user.create({
      data: {
        email,
        passwordHash,
        firstName: data.firstName.trim(),
        dateOfBirth: new Date(data.dateOfBirth),
        country: data.country,
      },
    });

    const rawToken = crypto.randomBytes(32).toString("hex");
    const tokenHash = crypto.createHash("sha256").update(rawToken).digest("hex");
    await db.emailVerificationToken.create({
      data: {
        userId: user.id,
        tokenHash,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      },
    });

    await sendVerificationEmail(user.email, user.firstName, rawToken);

    return apiOk({ ok: true, userId: user.id });
  } catch (err) {
    return handleApiError(err);
  }
}
