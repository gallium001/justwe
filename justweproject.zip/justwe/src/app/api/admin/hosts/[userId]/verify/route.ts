import { NextRequest } from "next/server";
import { requireAdmin } from "@/lib/session";
import { db } from "@/lib/db";
import { apiOk, apiError, handleApiError } from "@/lib/utils";

export async function PATCH(req: NextRequest, { params }: { params: { userId: string } }) {
  try {
    const admin = await requireAdmin();
    const { status } = await req.json(); // "UNVERIFIED" | "PENDING" | "VERIFIED"

    if (!["UNVERIFIED", "PENDING", "VERIFIED"].includes(status)) {
      return apiError("Invalid verification status", 422);
    }

    const record = await db.hostVerification.upsert({
      where: { userId: params.userId },
      update: { status, reviewedBy: admin.id, reviewedAt: new Date() },
      create: { userId: params.userId, status, reviewedBy: admin.id, reviewedAt: new Date() },
    });

    return apiOk(record);
  } catch (err) {
    return handleApiError(err);
  }
}
