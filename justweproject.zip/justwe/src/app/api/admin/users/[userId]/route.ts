import { NextRequest } from "next/server";
import { requireAdmin } from "@/lib/session";
import { db } from "@/lib/db";
import { apiOk, apiError, handleApiError } from "@/lib/utils";

export async function PATCH(req: NextRequest, { params }: { params: { userId: string } }) {
  try {
    await requireAdmin();
    const { action } = await req.json(); // "SUSPEND" | "REINSTATE"

    if (!["SUSPEND", "REINSTATE"].includes(action)) return apiError("Invalid action", 422);

    const updated = await db.user.update({
      where: { id: params.userId },
      data: { accountStatus: action === "SUSPEND" ? "SUSPENDED" : "ACTIVE" },
    });

    const { passwordHash, ...safe } = updated;
    return apiOk(safe);
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { userId: string } }) {
  try {
    await requireAdmin();
    // Soft delete: preserve rows for referential integrity/audit, but scrub PII
    // and mark inactive. Hard-delete is available via db:studio for GDPR-style
    // erasure requests if required by policy.
    await db.user.update({
      where: { id: params.userId },
      data: {
        accountStatus: "DELETED",
        datingProfileActive: false,
        email: `deleted-${params.userId}@justwe.invalid`,
        bio: null,
        profilePhotoUrl: null,
      },
    });
    return apiOk({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
