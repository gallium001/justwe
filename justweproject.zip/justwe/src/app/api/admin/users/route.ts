import { NextRequest } from "next/server";
import { requireAdmin } from "@/lib/session";
import { db } from "@/lib/db";
import { apiOk, handleApiError, calculateAge } from "@/lib/utils";

export async function GET(req: NextRequest) {
  try {
    await requireAdmin();
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim();

    const users = await db.user.findMany({
      where: q
        ? { OR: [{ email: { contains: q, mode: "insensitive" } }, { firstName: { contains: q, mode: "insensitive" } }] }
        : {},
      select: {
        id: true, email: true, firstName: true, dateOfBirth: true, country: true,
        role: true, accountStatus: true, isHost: true, datingProfileActive: true,
        emailVerified: true, createdAt: true,
      },
      orderBy: { createdAt: "desc" },
      take: 100,
    });

    const result = users.map((u) => ({ ...u, age: calculateAge(u.dateOfBirth) }));
    return apiOk(result);
  } catch (err) {
    return handleApiError(err);
  }
}
