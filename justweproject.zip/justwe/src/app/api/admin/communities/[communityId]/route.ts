import { requireAdmin } from "@/lib/session";
import { db } from "@/lib/db";
import { apiOk, handleApiError } from "@/lib/utils";

export async function DELETE(_req: Request, { params }: { params: { communityId: string } }) {
  try {
    await requireAdmin();
    await db.community.delete({ where: { id: params.communityId } });
    return apiOk({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
