import { requireAdmin } from "@/lib/session";
import { db } from "@/lib/db";
import { apiOk, handleApiError } from "@/lib/utils";

export async function GET() {
  try {
    await requireAdmin();
    const communities = await db.community.findMany({
      include: {
        host: { select: { id: true, firstName: true, email: true } },
        _count: { select: { memberships: { where: { status: "APPROVED" } } } },
      },
      orderBy: { createdAt: "desc" },
    });
    return apiOk(communities);
  } catch (err) {
    return handleApiError(err);
  }
}
