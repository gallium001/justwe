import { NextRequest } from "next/server";
import { requireAdmin } from "@/lib/session";
import { db } from "@/lib/db";
import { apiOk, apiError, handleApiError } from "@/lib/utils";

export async function PATCH(req: NextRequest, { params }: { params: { reportId: string } }) {
  try {
    await requireAdmin();
    const { status, adminNotes } = await req.json();

    if (status && !["OPEN", "REVIEWED", "ACTIONED", "DISMISSED"].includes(status)) {
      return apiError("Invalid status", 422);
    }

    const updated = await db.report.update({
      where: { id: params.reportId },
      data: { status, adminNotes },
    });

    return apiOk(updated);
  } catch (err) {
    return handleApiError(err);
  }
}
