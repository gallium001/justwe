import { requireAdmin } from "@/lib/session";
import { db } from "@/lib/db";
import { apiOk, handleApiError } from "@/lib/utils";

export async function GET() {
  try {
    await requireAdmin();
    const reports = await db.report.findMany({
      include: {
        reporter: { select: { id: true, firstName: true, email: true } },
        reportedUser: { select: { id: true, firstName: true, email: true, accountStatus: true } },
      },
      orderBy: { createdAt: "desc" },
    });
    return apiOk(reports);
  } catch (err) {
    return handleApiError(err);
  }
}
