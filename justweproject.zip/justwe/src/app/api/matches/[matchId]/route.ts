import { requireUser } from "@/lib/session";
import { db } from "@/lib/db";
import { serializeMatchForParticipant } from "@/lib/authorization";
import { apiOk, apiError, handleApiError, calculateAge } from "@/lib/utils";
import { formatPublicLocation } from "@/lib/location";

export async function GET(_req: Request, { params }: { params: { matchId: string } }) {
  try {
    const user = await requireUser();
    const match = await db.match.findUnique({ where: { id: params.matchId } });
    if (!match) return apiError("Match not found", 404);

    const base = serializeMatchForParticipant(match, user.id); // throws Forbidden if not a participant

    if (!("otherUserId" in base)) return apiOk(base);

    const other = await db.user.findUnique({
      where: { id: base.otherUserId },
      select: {
        id: true, firstName: true, profilePhotoUrl: true, dateOfBirth: true,
        country: true, region: true, city: true, locationVisibility: true, bio: true,
      },
    });

    return apiOk({
      ...base,
      otherUser: other
        ? {
            id: other.id,
            firstName: other.firstName,
            profilePhotoUrl: other.profilePhotoUrl,
            age: calculateAge(other.dateOfBirth),
            location: formatPublicLocation(other),
            bio: other.bio,
          }
        : null,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
