import { requireUser } from "@/lib/session";
import { db } from "@/lib/db";
import { serializeMatchForParticipant } from "@/lib/authorization";
import { apiOk, handleApiError, calculateAge } from "@/lib/utils";
import { formatPublicLocation } from "@/lib/location";

export async function GET() {
  try {
    const user = await requireUser();

    const matches = await db.match.findMany({
      where: { OR: [{ userAId: user.id }, { userBId: user.id }] },
      orderBy: { createdAt: "desc" },
    });

    const results = await Promise.all(
      matches.map(async (m) => {
        const base = serializeMatchForParticipant(m, user.id);
        if (!("otherUserId" in base)) return base; // pending/rejected — anonymous

        const other = await db.user.findUnique({
          where: { id: base.otherUserId },
          select: {
            id: true, firstName: true, profilePhotoUrl: true, dateOfBirth: true,
            country: true, region: true, city: true, locationVisibility: true,
          },
        });
        if (!other) return base;

        return {
          ...base,
          otherUser: {
            id: other.id,
            firstName: other.firstName,
            profilePhotoUrl: other.profilePhotoUrl,
            age: calculateAge(other.dateOfBirth),
            location: formatPublicLocation(other),
          },
        };
      })
    );

    return apiOk(results);
  } catch (err) {
    return handleApiError(err);
  }
}
