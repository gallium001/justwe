import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { requireApprovedMember, isBlockedEitherWay } from "@/lib/authorization";
import { db } from "@/lib/db";
import { likeSchema } from "@/lib/validators";
import { apiOk, apiError, handleApiError } from "@/lib/utils";
import { createNotification, NotificationCopy } from "@/lib/notifications";
import { sendMutualLikePendingEmail } from "@/lib/email";

/**
 * Records a Like. If the target has already liked the current user back
 * (in the same community), atomically creates a PENDING_HOST_REVIEW Match
 * and notifies BOTH users with fully anonymous copy — never the counterparty's
 * identity (spec §24-27). The response to the liker also never reveals
 * whether this specific like completed a mutual match beyond a generic flag,
 * since even that combined with timing could leak identity in a two-person
 * community; we keep the response uniform.
 */
export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const data = likeSchema.parse(await req.json());

    if (data.toUserId === user.id) return apiError("You cannot like your own profile", 422);

    const blocked = await isBlockedEitherWay(user.id, data.toUserId);
    if (blocked) return apiError("Unable to like this profile", 403);

    // Both users must be approved members of the stated community — this is
    // also the community whose host will adjudicate any resulting match.
    await requireApprovedMember(user.id, data.communityId);
    await requireApprovedMember(data.toUserId, data.communityId);

    const target = await db.user.findUnique({ where: { id: data.toUserId }, select: { datingProfileActive: true } });
    if (!target?.datingProfileActive) return apiError("This profile is not currently available", 404);

    const existingLike = await db.like.findUnique({
      where: { fromUserId_toUserId_communityId: { fromUserId: user.id, toUserId: data.toUserId, communityId: data.communityId } },
    });
    if (existingLike) return apiOk({ ok: true, alreadyLiked: true });

    await db.like.create({
      data: { fromUserId: user.id, toUserId: data.toUserId, communityId: data.communityId },
    });

    // Check for the reverse like → mutual match.
    const reverseLike = await db.like.findUnique({
      where: { fromUserId_toUserId_communityId: { fromUserId: data.toUserId, toUserId: user.id, communityId: data.communityId } },
    });

    if (reverseLike) {
      await createMutualMatch(user.id, data.toUserId, data.communityId);
    }

    return apiOk({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}

async function createMutualMatch(userAId: string, userBId: string, communityId: string) {
  // Canonicalize ordering so the unique constraint (userAId, userBId, communityId)
  // can't be bypassed by swapping the two ids across separate like events.
  const [first, second] = [userAId, userBId].sort();

  const existingMatch = await db.match.findUnique({
    where: { userAId_userBId_communityId: { userAId: first, userBId: second, communityId } },
  });
  if (existingMatch) return existingMatch;

  const match = await db.match.create({
    data: { userAId: first, userBId: second, communityId, status: "PENDING_HOST_REVIEW" },
  });

  const [userA, userB] = await Promise.all([
    db.user.findUnique({ where: { id: first }, select: { email: true, firstName: true } }),
    db.user.findUnique({ where: { id: second }, select: { email: true, firstName: true } }),
  ]);

  const copy = NotificationCopy.mutualLikePending;

  // Anonymous notification to BOTH participants — metadata carries only the
  // matchId for internal routing; no field here identifies the counterparty.
  await Promise.all([
    createNotification({ userId: first, type: "MUTUAL_LIKE_PENDING", title: copy.title, body: copy.body, metadata: { matchId: match.id } }),
    createNotification({ userId: second, type: "MUTUAL_LIKE_PENDING", title: copy.title, body: copy.body, metadata: { matchId: match.id } }),
    userA ? sendMutualLikePendingEmail(userA.email, userA.firstName) : Promise.resolve(),
    userB ? sendMutualLikePendingEmail(userB.email, userB.firstName) : Promise.resolve(),
  ]);

  return match;
}
