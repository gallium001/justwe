import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { requireProfileAccess } from "@/lib/authorization";
import { db } from "@/lib/db";
import { apiOk, handleApiError, PHOTO_VIEW_DEBOUNCE_MS } from "@/lib/utils";

/**
 * Returns the target user's photo gallery IF the viewer is authorized, and
 * records a view for each photo (debounced — see recordView below). The
 * response never includes likes/comments/reactions (spec §17) and never
 * includes other viewers' identities (spec §19-20) — only the aggregate
 * viewCount, which is only meaningful to the owner via /api/me/photos.
 */
export async function GET(_req: NextRequest, { params }: { params: { userId: string } }) {
  try {
    const viewer = await requireUser();
    await requireProfileAccess(viewer.id, params.userId);

    const photos = await db.datingPhoto.findMany({
      where: { userId: params.userId },
      orderBy: { displayOrder: "asc" },
      select: { id: true, imageUrl: true, thumbnailUrl: true, displayOrder: true },
      // NOTE: viewCount intentionally omitted here — a viewer browsing someone
      // else's gallery has no legitimate need to see the count; only the owner
      // sees it, via GET /api/me/photos.
    });

    // Fire-and-forget view recording; failures shouldn't block gallery display.
    recordViews(viewer.id, params.userId, photos.map((p) => p.id)).catch(() => {});

    return apiOk(photos);
  } catch (err) {
    return handleApiError(err);
  }
}

async function recordViews(viewerId: string, profileOwnerId: string, photoIds: string[]) {
  if (viewerId === profileOwnerId) return; // don't count self-views
  const cutoff = new Date(Date.now() - PHOTO_VIEW_DEBOUNCE_MS);

  for (const photoId of photoIds) {
    const recent = await db.datingPhotoView.findFirst({
      where: { photoId, viewerId, createdAt: { gte: cutoff } },
      select: { id: true },
    });
    if (recent) continue; // debounce: don't inflate the count on refresh/re-open

    await db.$transaction([
      db.datingPhotoView.create({ data: { photoId, viewerId, profileOwnerId } }),
      db.datingPhoto.update({ where: { id: photoId }, data: { viewCount: { increment: 1 } } }),
    ]);
  }
}
