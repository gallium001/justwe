import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { requireProfileAccess } from "@/lib/authorization";
import { db } from "@/lib/db";
import { apiOk, apiError, handleApiError, calculateAge } from "@/lib/utils";
import { formatPublicLocation } from "@/lib/location";

export async function GET(_req: NextRequest, { params }: { params: { userId: string } }) {
  try {
    const viewer = await requireUser();
    // Enforces: shared approved community, dating active, not blocked (spec §21-22).
    await requireProfileAccess(viewer.id, params.userId);

    const target = await db.user.findUnique({
      where: { id: params.userId },
      select: {
        id: true, firstName: true, dateOfBirth: true, gender: true,
        country: true, region: true, city: true, locationVisibility: true,
        bio: true, profilePhotoUrl: true, jwStatus: true, spiritualGoals: true,
        lookingFor: true, relationshipGoals: true, marriageIntention: true,
        longDistancePreference: true, interests: true, languages: true, lifestyleNotes: true,
      },
    });
    if (!target) return apiError("Profile not found", 404);

    return apiOk({
      id: target.id,
      firstName: target.firstName,
      age: calculateAge(target.dateOfBirth),
      gender: target.gender,
      location: formatPublicLocation(target),
      bio: target.bio,
      profilePhotoUrl: target.profilePhotoUrl,
      jwStatus: target.jwStatus,
      spiritualGoals: target.spiritualGoals,
      lookingFor: target.lookingFor,
      relationshipGoals: target.relationshipGoals,
      marriageIntention: target.marriageIntention,
      longDistancePreference: target.longDistancePreference,
      interests: target.interests,
      languages: target.languages,
      lifestyleNotes: target.lifestyleNotes,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
