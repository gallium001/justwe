import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { db } from "@/lib/db";
import { reportSchema } from "@/lib/validators";
import { apiOk, apiError, handleApiError } from "@/lib/utils";
import { checkRateLimit } from "@/lib/rate-limit";

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const { allowed } = checkRateLimit("report", user.id, 10, 60_000);
    if (!allowed) return apiError("Too many reports submitted. Please try again shortly.", 429);

    const data = reportSchema.parse(await req.json());
    if (data.reportedUserId === user.id) return apiError("You cannot report yourself", 422);

    const report = await db.report.create({
      data: {
        reporterId: user.id,
        reportedUserId: data.reportedUserId,
        reason: data.reason,
        details: data.details,
      },
    });

    // Reports are visible only to admins (see /api/admin/reports). The reporter's
    // identity is never surfaced to the reported user anywhere in the product.
    return apiOk({ ok: true, reportId: report.id }, 201);
  } catch (err) {
    return handleApiError(err);
  }
}
