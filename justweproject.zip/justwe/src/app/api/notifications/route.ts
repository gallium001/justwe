import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { db } from "@/lib/db";
import { apiOk, handleApiError } from "@/lib/utils";

export async function GET() {
  try {
    const user = await requireUser();
    const notifications = await db.notification.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      take: 100,
      // metadata is returned as-is; it only ever contains internal ids (matchId,
      // communityId, postId) — never a counterparty's name/photo, enforced at
      // write-time in src/lib/notifications.ts.
    });
    return apiOk(notifications);
  } catch (err) {
    return handleApiError(err);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const user = await requireUser();
    const { notificationId, markAllRead } = await req.json();

    if (markAllRead) {
      await db.notification.updateMany({
        where: { userId: user.id, readAt: null },
        data: { readAt: new Date() },
      });
      return apiOk({ ok: true });
    }

    if (notificationId) {
      await db.notification.updateMany({
        where: { id: notificationId, userId: user.id },
        data: { readAt: new Date() },
      });
      return apiOk({ ok: true });
    }

    return apiOk({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
