import { requireUser } from "@/lib/session";
import { db } from "@/lib/db";
import { apiOk, handleApiError, calculateAge } from "@/lib/utils";
import { formatPublicLocation } from "@/lib/location";

/**
 * Host-only endpoint. Only matches belonging to communities THIS user hosts
 * are returned — a host can never see matches from unrelated communities
 * (spec §29, §60). Full participant profiles are included since the host is
 * the designated adjudicator for this decision, but sensitive account fields
 * (password, email, private messages) are still excluded.
 */
export async function GET() {
  try {
    const user = await requireUser();

    const hostedCommunityIds = (
      await db.community.findMany({ where: { hostId: user.id }, select: { id: true } })
    ).map((c) => c.id);

    if (hostedCommunityIds.length === 0) return apiOk([]);

    const matches = await db.match.findMany({
      where: { communityId: { in: hostedCommunityIds }, status: "PENDING_HOST_REVIEW" },
      include: {
        community: { select: { id: true, name: true } },
        userA: { select: profileSelect },
        userB: { select: profileSelect },
      },
      orderBy: { createdAt: "asc" },
    });

    const result = matches.map((m) => ({
      id: m.id,
      status: m.status,
      createdAt: m.createdAt,
      community: m.community,
      userA: serializeForHost(m.userA),
      userB: serializeForHost(m.userB),
    }));

    return apiOk(result);
  } catch (err) {
    return handleApiError(err);
  }
}

const profileSelect = {
  id: true, firstName: true, dateOfBirth: true, gender: true, profilePhotoUrl: true,
  country: true, region: true, city: true, locationVisibility: true, bio: true,
  jwStatus: true, spiritualGoals: true, relationshipGoals: true, marriageIntention: true,
  longDistancePreference: true, interests: true,
} as const;

function serializeForHost(u: any) {
  return {
    id: u.id,
    firstName: u.firstName,
    age: calculateAge(u.dateOfBirth),
    gender: u.gender,
    profilePhotoUrl: u.profilePhotoUrl,
    location: formatPublicLocation(u),
    bio: u.bio,
    jwStatus: u.jwStatus,
    spiritualGoals: u.spiritualGoals,
    relationshipGoals: u.relationshipGoals,
    marriageIntention: u.marriageIntention,
    longDistancePreference: u.longDistancePreference,
    interests: u.interests,
  };
}
