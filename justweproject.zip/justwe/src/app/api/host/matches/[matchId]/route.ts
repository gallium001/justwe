import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { requireHostMatchAccess } from "@/lib/authorization";
import { db } from "@/lib/db";
import { matchDecisionSchema } from "@/lib/validators";
import { apiOk, apiError, handleApiError } from "@/lib/utils";
import { createNotification, NotificationCopy } from "@/lib/notifications";
import { sendMatchApprovedEmail, sendMatchRejectedEmail } from "@/lib/email";

export async function PATCH(req: NextRequest, { params }: { params: { matchId: string } }) {
  try {
    const user = await requireUser();
    const match = await requireHostMatchAccess(user.id, user.role, params.matchId);
    const { action } = matchDecisionSchema.parse(await req.json());

    if (match.status !== "PENDING_HOST_REVIEW") {
      return apiError("This match has already been reviewed", 409);
    }

    const newStatus = action === "APPROVE" ? "APPROVED" : "REJECTED";

    await db.match.update({
      where: { id: match.id },
      data: { status: newStatus, reviewedBy: user.id, reviewedAt: new Date() },
    });

    const [userA, userB] = await Promise.all([
      db.user.findUnique({ where: { id: match.userAId }, select: { id: true, email: true, firstName: true } }),
      db.user.findUnique({ where: { id: match.userBId }, select: { id: true, email: true, firstName: true } }),
    ]);

    const copy = action === "APPROVE" ? NotificationCopy.matchApproved : NotificationCopy.matchRejected;
    const notifType = action === "APPROVE" ? "MATCH_APPROVED" : "MATCH_REJECTED";

    await Promise.all([
      createNotification({ userId: match.userAId, type: notifType, title: copy.title, body: copy.body, metadata: { matchId: match.id } }),
      createNotification({ userId: match.userBId, type: notifType, title: copy.title, body: copy.body, metadata: { matchId: match.id } }),
      userA ? (action === "APPROVE" ? sendMatchApprovedEmail(userA.email, userA.firstName) : sendMatchRejectedEmail(userA.email, userA.firstName)) : Promise.resolve(),
      userB ? (action === "APPROVE" ? sendMatchApprovedEmail(userB.email, userB.firstName) : sendMatchRejectedEmail(userB.email, userB.firstName)) : Promise.resolve(),
    ]);

    return apiOk({ ok: true, status: newStatus });
  } catch (err) {
    return handleApiError(err);
  }
}
