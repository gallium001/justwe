import { NextRequest } from "next/server";
import { requireUser, ForbiddenError } from "@/lib/session";
import { isBlockedEitherWay } from "@/lib/authorization";
import { db } from "@/lib/db";
import { messageSchema } from "@/lib/validators";
import { apiOk, apiError, handleApiError } from "@/lib/utils";
import { createNotification, NotificationCopy } from "@/lib/notifications";

async function assertApprovedParticipant(userId: string, matchId: string) {
  const match = await db.match.findUnique({ where: { id: matchId } });
  if (!match) throw new ForbiddenError("Match not found");
  const isParticipant = match.userAId === userId || match.userBId === userId;
  if (!isParticipant) throw new ForbiddenError("Not a participant in this match");
  if (match.status !== "APPROVED") throw new ForbiddenError("Messaging is only available after host approval");
  return match;
}

export async function GET(_req: NextRequest, { params }: { params: { matchId: string } }) {
  try {
    const user = await requireUser();
    const match = await assertApprovedParticipant(user.id, params.matchId);

    const messages = await db.message.findMany({
      where: { matchId: params.matchId },
      orderBy: { createdAt: "asc" },
    });

    // Mark messages sent to me as read.
    await db.message.updateMany({
      where: { matchId: params.matchId, receiverId: user.id, readAt: null },
      data: { readAt: new Date() },
    });

    return apiOk(messages);
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest, { params }: { params: { matchId: string } }) {
  try {
    const user = await requireUser();
    const data = messageSchema.parse({ ...(await req.json()), matchId: params.matchId });
    const match = await assertApprovedParticipant(user.id, params.matchId);

    const receiverId = match.userAId === user.id ? match.userBId : match.userAId;

    const blocked = await isBlockedEitherWay(user.id, receiverId);
    if (blocked) return apiError("You are unable to message this person", 403);

    const message = await db.message.create({
      data: { matchId: params.matchId, senderId: user.id, receiverId, body: data.body },
    });

    const copy = NotificationCopy.newMessage();
    await createNotification({
      userId: receiverId,
      type: "NEW_MESSAGE",
      title: copy.title,
      body: copy.body,
      metadata: { matchId: params.matchId },
    });

    return apiOk(message, 201);
  } catch (err) {
    return handleApiError(err);
  }
}
