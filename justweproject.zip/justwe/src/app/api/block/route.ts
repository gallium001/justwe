import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { db } from "@/lib/db";
import { blockSchema } from "@/lib/validators";
import { apiOk, apiError, handleApiError } from "@/lib/utils";

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const { blockedId } = blockSchema.parse(await req.json());

    if (blockedId === user.id) return apiError("You cannot block yourself", 422);

    await db.block.upsert({
      where: { blockerId_blockedId: { blockerId: user.id, blockedId } },
      update: {},
      create: { blockerId: user.id, blockedId },
    });

    return apiOk({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const user = await requireUser();
    const { blockedId } = blockSchema.parse(await req.json());
    await db.block.deleteMany({ where: { blockerId: user.id, blockedId } });
    return apiOk({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
