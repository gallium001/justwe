import { NextRequest } from "next/server";
import { requireUser, getCurrentUser } from "@/lib/session";
import { db } from "@/lib/db";
import { communityCreateSchema } from "@/lib/validators";
import { apiOk, handleApiError } from "@/lib/utils";
import { formatPublicLocation } from "@/lib/location";

/**
 * Public community discovery. Only PUBLIC communities are listed here.
 * Individual dating members are NEVER included in this response (spec §7) —
 * only host + community summary info.
 */
export async function GET(req: NextRequest) {
  try {
    const viewer = await getCurrentUser(); // optional — discovery works logged out too, but joining requires auth
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim();
    const focus = searchParams.get("focus");

    const communities = await db.community.findMany({
      where: {
        visibility: "PUBLIC",
        ...(q ? { name: { contains: q, mode: "insensitive" } } : {}),
        ...(focus ? { geographicFocus: focus as any } : {}),
      },
      include: {
        host: {
          select: {
            id: true,
            firstName: true,
            profilePhotoUrl: true,
            country: true,
            region: true,
            city: true,
            locationVisibility: true,
            hostVerification: { select: { status: true } },
          },
        },
        _count: { select: { memberships: { where: { status: "APPROVED" } } } },
      },
      orderBy: { createdAt: "desc" },
      take: 60,
    });

    const cards = communities.map((c) => ({
      id: c.id,
      name: c.name,
      description: c.description,
      imageUrl: c.imageUrl,
      geographicFocus: c.geographicFocus,
      memberCount: c._count.memberships,
      rulesSummary: c.rules.length > 160 ? c.rules.slice(0, 160) + "…" : c.rules,
      host: {
        id: c.host.id,
        firstName: c.host.firstName,
        profilePhotoUrl: c.host.profilePhotoUrl,
        location: formatPublicLocation(c.host),
        verified: c.host.hostVerification?.status === "VERIFIED",
      },
    }));

    return apiOk(cards);
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const data = communityCreateSchema.parse(await req.json());

    const community = await db.community.create({
      data: {
        hostId: user.id,
        name: data.name,
        description: data.description,
        hostIntroduction: data.hostIntroduction,
        geographicFocus: data.geographicFocus,
        focusCountry: data.focusCountry,
        focusRegion: data.focusRegion,
        focusCity: data.focusCity,
        imageUrl: data.imageUrl,
        visibility: data.visibility,
        rules: data.rules,
        inviteCode: data.visibility === "INVITE_ONLY" ? cryptoRandom() : null,
      },
    });

    if (!user.isHost) {
      await db.user.update({ where: { id: user.id }, data: { isHost: true } });
    }

    // Auto-approve the host as a member of their own community so they can see it in "My Communities".
    await db.communityMembership.create({
      data: {
        communityId: community.id,
        userId: user.id,
        status: "APPROVED",
        decidedAt: new Date(),
        decidedBy: user.id,
      },
    });

    return apiOk(community, 201);
  } catch (err) {
    return handleApiError(err);
  }
}

function cryptoRandom() {
  return Math.random().toString(36).slice(2, 10).toUpperCase();
}
