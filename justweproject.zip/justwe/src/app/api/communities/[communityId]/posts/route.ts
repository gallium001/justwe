import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { requireCommunityHost } from "@/lib/authorization";
import { db } from "@/lib/db";
import { communityPostSchema } from "@/lib/validators";
import { apiOk, apiError, handleApiError } from "@/lib/utils";
import { createNotification, NotificationCopy } from "@/lib/notifications";

export async function GET(_req: NextRequest, { params }: { params: { communityId: string } }) {
  try {
    const user = await requireUser();
    const membership = await db.communityMembership.findUnique({
      where: { communityId_userId: { communityId: params.communityId, userId: user.id } },
    });
    const community = await db.community.findUnique({ where: { id: params.communityId } });
    const isHost = community?.hostId === user.id;
    if (!isHost && membership?.status !== "APPROVED") {
      return apiError("You must be a member to view this community's posts", 403);
    }

    const posts = await db.communityPost.findMany({
      where: { communityId: params.communityId },
      include: { author: { select: { id: true, firstName: true, profilePhotoUrl: true } } },
      orderBy: { createdAt: "desc" },
      take: 50,
    });

    return apiOk(posts);
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest, { params }: { params: { communityId: string } }) {
  try {
    const user = await requireUser();
    await requireCommunityHost(user.id, params.communityId);
    const data = communityPostSchema.parse(await req.json());

    const post = await db.communityPost.create({
      data: { communityId: params.communityId, authorId: user.id, body: data.body, imageUrl: data.imageUrl },
    });

    const community = await db.community.findUnique({ where: { id: params.communityId } });
    const members = await db.communityMembership.findMany({
      where: { communityId: params.communityId, status: "APPROVED", userId: { not: user.id } },
      select: { userId: true },
    });

    const copy = NotificationCopy.newPost(community?.name ?? "Your community");
    await Promise.all(
      members.map((m) =>
        createNotification({
          userId: m.userId,
          type: "NEW_COMMUNITY_POST",
          title: copy.title,
          body: copy.body,
          metadata: { communityId: params.communityId, postId: post.id },
        })
      )
    );

    return apiOk(post, 201);
  } catch (err) {
    return handleApiError(err);
  }
}
