import { NextRequest } from "next/server";
import { requireUser, getCurrentUser, ForbiddenError } from "@/lib/session";
import { requireCommunityHost } from "@/lib/authorization";
import { db } from "@/lib/db";
import { communityUpdateSchema } from "@/lib/validators";
import { apiOk, apiError, handleApiError } from "@/lib/utils";
import { formatPublicLocation } from "@/lib/location";

export async function GET(_req: NextRequest, { params }: { params: { communityId: string } }) {
  try {
    const viewer = await getCurrentUser();
    const community = await db.community.findUnique({
      where: { id: params.communityId },
      include: {
        host: {
          select: {
            id: true, firstName: true, profilePhotoUrl: true, bio: true,
            country: true, region: true, city: true, locationVisibility: true,
            hostVerification: { select: { status: true } },
          },
        },
        _count: { select: { memberships: { where: { status: "APPROVED" } } } },
      },
    });
    if (!community) return apiError("Community not found", 404);

    // Invite-only communities are hidden from anyone who isn't already a member/host.
    if (community.visibility === "INVITE_ONLY") {
      const isHost = viewer?.id === community.hostId;
      const isMember = viewer
        ? await db.communityMembership.findUnique({
            where: { communityId_userId: { communityId: community.id, userId: viewer.id } },
          })
        : null;
      if (!isHost && !isMember) return apiError("Community not found", 404);
    }

    let myMembershipStatus: string | null = null;
    if (viewer) {
      const m = await db.communityMembership.findUnique({
        where: { communityId_userId: { communityId: community.id, userId: viewer.id } },
        select: { status: true },
      });
      myMembershipStatus = m?.status ?? null;
    }

    return apiOk({
      id: community.id,
      name: community.name,
      description: community.description,
      hostIntroduction: community.hostIntroduction,
      geographicFocus: community.geographicFocus,
      focusCountry: community.focusCountry,
      focusRegion: community.focusRegion,
      focusCity: community.focusCity,
      imageUrl: community.imageUrl,
      visibility: community.visibility,
      rules: community.rules,
      memberCount: community._count.memberships,
      createdAt: community.createdAt,
      host: {
        id: community.host.id,
        firstName: community.host.firstName,
        profilePhotoUrl: community.host.profilePhotoUrl,
        bio: community.host.bio,
        location: formatPublicLocation(community.host),
        verified: community.host.hostVerification?.status === "VERIFIED",
      },
      myMembershipStatus,
      isMine: viewer?.id === community.hostId,
    });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { communityId: string } }) {
  try {
    const user = await requireUser();
    await requireCommunityHost(user.id, params.communityId);
    const data = communityUpdateSchema.parse(await req.json());

    const updated = await db.community.update({
      where: { id: params.communityId },
      data,
    });
    return apiOk(updated);
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { communityId: string } }) {
  try {
    const user = await requireUser();
    await requireCommunityHost(user.id, params.communityId);
    await db.community.delete({ where: { id: params.communityId } });
    return apiOk({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
