import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { requireCommunityHost } from "@/lib/authorization";
import { db } from "@/lib/db";
import { apiOk, handleApiError } from "@/lib/utils";
import { formatPublicLocation } from "@/lib/location";
import { calculateAge } from "@/lib/utils";

export async function GET(req: NextRequest, { params }: { params: { communityId: string } }) {
  try {
    const user = await requireUser();
    await requireCommunityHost(user.id, params.communityId);

    const { searchParams } = new URL(req.url);
    const status = (searchParams.get("status") || "APPROVED").toUpperCase();

    const memberships = await db.communityMembership.findMany({
      where: { communityId: params.communityId, status: status as any },
      include: {
        user: {
          select: {
            id: true, firstName: true, dateOfBirth: true, gender: true, profilePhotoUrl: true,
            country: true, region: true, city: true, locationVisibility: true,
            datingProfileActive: true, bio: true,
          },
        },
      },
      orderBy: { requestedAt: "desc" },
    });

    const result = memberships.map((m) => ({
      membershipId: m.id,
      status: m.status,
      requestedAt: m.requestedAt,
      decidedAt: m.decidedAt,
      introMessage: m.introMessage,
      user: {
        id: m.user.id,
        firstName: m.user.firstName,
        age: calculateAge(m.user.dateOfBirth),
        gender: m.user.gender,
        profilePhotoUrl: m.user.profilePhotoUrl,
        location: formatPublicLocation(m.user),
        datingProfileActive: m.user.datingProfileActive,
        bio: m.user.bio,
      },
    }));

    return apiOk(result);
  } catch (err) {
    return handleApiError(err);
  }
}
