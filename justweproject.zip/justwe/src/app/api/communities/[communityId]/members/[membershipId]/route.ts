import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { requireCommunityHost } from "@/lib/authorization";
import { db } from "@/lib/db";
import { membershipDecisionSchema } from "@/lib/validators";
import { apiOk, apiError, handleApiError } from "@/lib/utils";
import { createNotification, NotificationCopy } from "@/lib/notifications";
import { sendJoinRequestDecisionEmail } from "@/lib/email";

export async function PATCH(
  req: NextRequest,
  { params }: { params: { communityId: string; membershipId: string } }
) {
  try {
    const user = await requireUser();
    const community = await requireCommunityHost(user.id, params.communityId);
    const { action } = membershipDecisionSchema.parse(await req.json());

    const membership = await db.communityMembership.findUnique({
      where: { id: params.membershipId },
      include: { user: { select: { id: true, firstName: true, email: true } } },
    });
    if (!membership || membership.communityId !== params.communityId) {
      return apiError("Membership request not found", 404);
    }

    const communityFull = await db.community.findUnique({ where: { id: params.communityId } });
    const communityName = communityFull?.name ?? "your community";

    if (action === "APPROVE") {
      await db.communityMembership.update({
        where: { id: membership.id },
        data: { status: "APPROVED", decidedAt: new Date(), decidedBy: user.id },
      });
      const copy = NotificationCopy.joinApproved(communityName);
      await createNotification({
        userId: membership.userId,
        type: "JOIN_REQUEST_APPROVED",
        title: copy.title,
        body: copy.body,
        metadata: { communityId: params.communityId },
      });
      await sendJoinRequestDecisionEmail(membership.user.email, membership.user.firstName, communityName, true);
    } else if (action === "REJECT") {
      await db.communityMembership.update({
        where: { id: membership.id },
        data: { status: "REJECTED", decidedAt: new Date(), decidedBy: user.id },
      });
      const copy = NotificationCopy.joinRejected(communityName);
      await createNotification({
        userId: membership.userId,
        type: "JOIN_REQUEST_REJECTED",
        title: copy.title,
        body: copy.body,
        metadata: { communityId: params.communityId },
      });
      await sendJoinRequestDecisionEmail(membership.user.email, membership.user.firstName, communityName, false);
    } else if (action === "REMOVE") {
      // Removal immediately revokes dating-profile access server-side because
      // requireApprovedMember / getApprovedCommunityIds checks live status on every request.
      await db.communityMembership.update({
        where: { id: membership.id },
        data: { status: "REMOVED", decidedAt: new Date(), decidedBy: user.id },
      });
      const copy = NotificationCopy.removedFromCommunity(communityName);
      await createNotification({
        userId: membership.userId,
        type: "REMOVED_FROM_COMMUNITY",
        title: copy.title,
        body: copy.body,
        metadata: { communityId: params.communityId },
      });
    }

    return apiOk({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
