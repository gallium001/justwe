import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { requireApprovedMember } from "@/lib/authorization";
import { db } from "@/lib/db";
import { apiOk, handleApiError, calculateAge } from "@/lib/utils";
import { formatPublicLocation } from "@/lib/location";

/**
 * Returns eligible dating profiles within a community the viewer has APPROVED
 * membership in. Deliberately performs NO geographic/distance filtering —
 * community membership is the only access boundary (spec §2, §22, §59).
 * Already-liked and blocked users are excluded so Discover doesn't repeat.
 */
export async function GET(_req: NextRequest, { params }: { params: { communityId: string } }) {
  try {
    const user = await requireUser();
    await requireApprovedMember(user.id, params.communityId);

    const [alreadyLiked, blocks] = await Promise.all([
      db.like.findMany({ where: { fromUserId: user.id, communityId: params.communityId }, select: { toUserId: true } }),
      db.block.findMany({
        where: { OR: [{ blockerId: user.id }, { blockedId: user.id }] },
        select: { blockerId: true, blockedId: true },
      }),
    ]);

    const excludeIds = new Set<string>([
      user.id,
      ...alreadyLiked.map((l) => l.toUserId),
      ...blocks.map((b) => (b.blockerId === user.id ? b.blockedId : b.blockerId)),
    ]);

    const candidates = await db.user.findMany({
      where: {
        datingProfileActive: true,
        id: { notIn: Array.from(excludeIds) },
        memberships: {
          some: { communityId: params.communityId, status: "APPROVED" },
        },
        // Deliberately: NO country/region/city filter here. Worldwide by design.
      },
      select: {
        id: true, firstName: true, dateOfBirth: true, gender: true,
        country: true, region: true, city: true, locationVisibility: true,
        bio: true, profilePhotoUrl: true, jwStatus: true, spiritualGoals: true,
        relationshipGoals: true, marriageIntention: true, longDistancePreference: true,
        interests: true, languages: true,
      },
      take: 30,
      orderBy: { createdAt: "desc" },
    });

    const profiles = candidates.map((c) => ({
      id: c.id,
      firstName: c.firstName,
      age: calculateAge(c.dateOfBirth),
      gender: c.gender,
      location: formatPublicLocation(c),
      bio: c.bio,
      profilePhotoUrl: c.profilePhotoUrl,
      jwStatus: c.jwStatus,
      spiritualGoals: c.spiritualGoals,
      relationshipGoals: c.relationshipGoals,
      marriageIntention: c.marriageIntention,
      longDistancePreference: c.longDistancePreference,
      interests: c.interests,
      languages: c.languages,
    }));

    return apiOk(profiles);
  } catch (err) {
    return handleApiError(err);
  }
}
