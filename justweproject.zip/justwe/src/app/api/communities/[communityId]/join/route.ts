import { NextRequest } from "next/server";
import { requireUser } from "@/lib/session";
import { db } from "@/lib/db";
import { joinRequestSchema } from "@/lib/validators";
import { apiOk, apiError, handleApiError } from "@/lib/utils";
import { createNotification, NotificationCopy } from "@/lib/notifications";

export async function POST(req: NextRequest, { params }: { params: { communityId: string } }) {
  try {
    const user = await requireUser();
    const body = await req.json().catch(() => ({}));
    const data = joinRequestSchema.parse({ ...body, communityId: params.communityId });

    const community = await db.community.findUnique({ where: { id: data.communityId } });
    if (!community) return apiError("Community not found", 404);
    if (community.hostId === user.id) return apiError("You already host this community", 422);

    const existing = await db.communityMembership.findUnique({
      where: { communityId_userId: { communityId: data.communityId, userId: user.id } },
    });

    if (existing && existing.status === "APPROVED") {
      return apiError("You're already a member of this community", 409);
    }
    if (existing && existing.status === "PENDING") {
      return apiError("Your request is already pending review", 409);
    }

    const membership = existing
      ? await db.communityMembership.update({
          where: { id: existing.id },
          data: { status: "PENDING", introMessage: data.introMessage, requestedAt: new Date(), decidedAt: null, decidedBy: null },
        })
      : await db.communityMembership.create({
          data: {
            communityId: data.communityId,
            userId: user.id,
            introMessage: data.introMessage,
            status: "PENDING",
          },
        });

    const copy = NotificationCopy.joinRequestReceived(user.firstName);
    await createNotification({
      userId: community.hostId,
      type: "JOIN_REQUEST_RECEIVED",
      title: copy.title,
      body: copy.body,
      metadata: { communityId: community.id, membershipId: membership.id },
    });

    return apiOk({ ok: true, status: membership.status }, 201);
  } catch (err) {
    return handleApiError(err);
  }
}
