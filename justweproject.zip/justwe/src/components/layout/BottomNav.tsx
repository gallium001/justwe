"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession } from "next-auth/react";
import { Users, Compass, Heart, MessageCircle, UserCircle, Shield } from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { href: "/communities", label: "Communities", icon: Users },
  { href: "/discover", label: "Discover", icon: Compass },
  { href: "/matches", label: "Matches", icon: Heart },
  { href: "/messages", label: "Messages", icon: MessageCircle },
  { href: "/profile", label: "Profile", icon: UserCircle },
];

export function BottomNav() {
  const pathname = usePathname();
  const { data: session } = useSession();
  if (!session) return null;

  const isHost = (session.user as any)?.isHost;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur border-t border-forest-100 md:hidden">
      <div className="flex items-stretch justify-around">
        {items.map(({ href, label, icon: Icon }) => {
          const active = pathname?.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex flex-1 flex-col items-center justify-center gap-1 py-2.5 text-xs font-medium transition-colors",
                active ? "text-brand-600" : "text-ink-400"
              )}
            >
              <Icon size={22} strokeWidth={active ? 2.5 : 2} />
              {label}
            </Link>
          );
        })}
        {isHost && (
          <Link
            href="/host"
            className={cn(
              "flex flex-1 flex-col items-center justify-center gap-1 py-2.5 text-xs font-medium transition-colors",
              pathname?.startsWith("/host") ? "text-forest-700" : "text-ink-400"
            )}
          >
            <Shield size={22} strokeWidth={pathname?.startsWith("/host") ? 2.5 : 2} />
            Host
          </Link>
        )}
      </div>
    </nav>
  );
}
