"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession, signOut } from "next-auth/react";
import { cn } from "@/lib/utils";
import { NotificationBell } from "@/components/layout/NotificationBell";

const items = [
  { href: "/communities", label: "Communities" },
  { href: "/discover", label: "Discover" },
  { href: "/matches", label: "Matches" },
  { href: "/messages", label: "Messages" },
];

export function TopNav() {
  const { data: session } = useSession();
  const pathname = usePathname();
  const isHost = (session?.user as any)?.isHost;
  const isAdmin = (session?.user as any)?.role === "ADMIN";

  return (
    <header className="hidden md:flex items-center justify-between px-8 py-4 sticky top-0 z-40 bg-white/80 backdrop-blur border-b border-forest-100">
      <Link href={session ? "/communities" : "/"} className="font-serif text-2xl font-semibold text-forest-800">
        Just<span className="text-brand-500">We</span>
      </Link>

      {session && (
        <nav className="flex items-center gap-1">
          {items.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "px-4 py-2 rounded-full text-sm font-medium transition-colors",
                pathname?.startsWith(item.href) ? "bg-forest-50 text-forest-800" : "text-ink-600 hover:bg-ink-50"
              )}
            >
              {item.label}
            </Link>
          ))}
          {isHost && (
            <Link
              href="/host"
              className={cn(
                "px-4 py-2 rounded-full text-sm font-medium transition-colors",
                pathname?.startsWith("/host") ? "bg-brand-50 text-brand-700" : "text-ink-600 hover:bg-ink-50"
              )}
            >
              Host Dashboard
            </Link>
          )}
          {isAdmin && (
            <Link
              href="/admin"
              className={cn(
                "px-4 py-2 rounded-full text-sm font-medium transition-colors",
                pathname?.startsWith("/admin") ? "bg-ink-800 text-white" : "text-ink-600 hover:bg-ink-50"
              )}
            >
              Admin
            </Link>
          )}
        </nav>
      )}

      <div className="flex items-center gap-3">
        {session ? (
          <>
            <NotificationBell />
            <Link href="/profile" className="text-sm font-medium text-ink-700 hover:text-forest-700">
              {session.user?.name}
            </Link>
            <button onClick={() => signOut({ callbackUrl: "/" })} className="text-sm text-ink-400 hover:text-brand-600">
              Sign out
            </button>
          </>
        ) : (
          <>
            <Link href="/login" className="text-sm font-medium text-ink-700 hover:text-forest-700">
              Log in
            </Link>
            <Link href="/register" className="btn-primary !px-5 !py-2 text-sm">
              Create Account
            </Link>
          </>
        )}
      </div>
    </header>
  );
}
