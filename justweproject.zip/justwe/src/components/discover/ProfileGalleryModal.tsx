"use client";

import { useEffect, useState } from "react";
import { X } from "lucide-react";

type Photo = { id: string; imageUrl: string; thumbnailUrl: string | null; displayOrder: number };

/**
 * Instagram-story-inspired full-screen gallery viewer. View-only: no likes,
 * comments, or reactions anywhere in this component (spec §16-17). Views are
 * recorded server-side automatically when photos are fetched.
 */
export function ProfileGalleryModal({ userId, onClose }: { userId: string; onClose: () => void }) {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [index, setIndex] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/profiles/${userId}/photos`)
      .then((r) => r.json())
      .then((data) => setPhotos(Array.isArray(data) ? data : []))
      .finally(() => setLoading(false));
  }, [userId]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "ArrowRight") setIndex((i) => Math.min(i + 1, photos.length - 1));
      if (e.key === "ArrowLeft") setIndex((i) => Math.max(i - 1, 0));
      if (e.key === "Escape") onClose();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [photos.length, onClose]);

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col animate-fade-in">
      <div className="flex gap-1 p-3">
        {photos.map((_, i) => (
          <div key={i} className="flex-1 h-1 rounded-full bg-white/30 overflow-hidden">
            <div className={`h-full bg-white transition-all ${i <= index ? "w-full" : "w-0"}`} />
          </div>
        ))}
      </div>
      <button onClick={onClose} className="absolute top-3 right-3 text-white p-2 z-10" aria-label="Close">
        <X size={26} />
      </button>

      <div className="flex-1 relative flex items-center justify-center select-none">
        {loading ? (
          <p className="text-white/60">Loading photos…</p>
        ) : photos.length === 0 ? (
          <p className="text-white/60">No photos yet.</p>
        ) : (
          <>
            <button
              className="absolute left-0 top-0 bottom-0 w-1/3"
              aria-label="Previous photo"
              onClick={() => setIndex((i) => Math.max(i - 1, 0))}
            />
            <img src={photos[index].imageUrl} alt="" className="max-h-full max-w-full object-contain" />
            <button
              className="absolute right-0 top-0 bottom-0 w-1/3"
              aria-label="Next photo"
              onClick={() => setIndex((i) => Math.min(i + 1, photos.length - 1))}
            />
          </>
        )}
      </div>
    </div>
  );
}
