"use client";

import { useEffect, useState } from "react";
import { useToast } from "@/components/ui/ToastProvider";
import { Trash2, Plus } from "lucide-react";

type Photo = { id: string; imageUrl: string; displayOrder: number; viewCount: number };

/** Owner-facing gallery manager. This is the ONLY place viewCount is ever shown. */
export function PhotoGalleryEditor() {
  const { push } = useToast();
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [uploading, setUploading] = useState(false);

  async function load() {
    const res = await fetch("/api/me/photos");
    if (res.ok) setPhotos(await res.json());
  }

  useEffect(() => { load(); }, []);

  async function onUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const presign = await fetch("/api/uploads/presign", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ folder: "dating-photos", contentType: file.type, fileSize: file.size }),
      });
      if (!presign.ok) {
        const data = await presign.json();
        push(data.error || "Upload not allowed", "error");
        return;
      }
      const { uploadUrl, publicUrl } = await presign.json();

      await fetch(uploadUrl, { method: "PUT", headers: { "Content-Type": file.type }, body: file });

      const res = await fetch("/api/me/photos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageUrl: publicUrl }),
      });
      if (res.ok) {
        push("Photo added.", "success");
        load();
      } else {
        const data = await res.json();
        push(data.error || "Could not save photo", "error");
      }
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  }

  async function remove(photoId: string) {
    await fetch(`/api/me/photos/${photoId}`, { method: "DELETE" });
    load();
  }

  return (
    <div>
      <div className="grid grid-cols-3 gap-3">
        {photos.map((p) => (
          <div key={p.id} className="relative aspect-square rounded-xl overflow-hidden bg-ink-50 group">
            <img src={p.imageUrl} className="w-full h-full object-cover" alt="" />
            <button
              onClick={() => remove(p.id)}
              className="absolute top-1.5 right-1.5 bg-black/50 text-white rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <Trash2 size={14} />
            </button>
            <span className="absolute bottom-1.5 left-1.5 bg-black/50 text-white text-[10px] rounded-full px-2 py-0.5">
              {p.viewCount} views
            </span>
          </div>
        ))}

        {photos.length < 9 && (
          <label className="aspect-square rounded-xl border-2 border-dashed border-ink-200 flex items-center justify-center cursor-pointer hover:border-forest-400 text-ink-400">
            <Plus size={24} />
            <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={onUpload} disabled={uploading} />
          </label>
        )}
      </div>
      <p className="text-xs text-ink-400 mt-3">
        Photos are only visible to members of communities you share. No one can like or comment on them — only you can see how many times each has been viewed.
      </p>
    </div>
  );
}
