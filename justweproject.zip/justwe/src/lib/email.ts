import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);
const FROM = process.env.EMAIL_FROM || "JustWe <hello@justwe.app>";
const APP_URL = process.env.NEXTAUTH_URL || "http://localhost:3000";

async function send(to: string, subject: string, html: string) {
  if (!process.env.RESEND_API_KEY) {
    // In local/dev without an email key configured, log instead of throwing so
    // the rest of the app keeps working.
    console.log(`[email:dev] to=${to} subject="${subject}"`);
    return;
  }
  await resend.emails.send({ from: FROM, to, subject, html });
}

export async function sendVerificationEmail(to: string, firstName: string, token: string) {
  const url = `${APP_URL}/verify-email?token=${token}`;
  await send(
    to,
    "Verify your JustWe account",
    `<p>Hi ${firstName},</p>
     <p>Welcome to JustWe. Please confirm your email address to activate your account:</p>
     <p><a href="${url}">Verify my email</a></p>
     <p>If you didn't create this account, you can ignore this email.</p>`
  );
}

export async function sendPasswordResetEmail(to: string, firstName: string, token: string) {
  const url = `${APP_URL}/reset-password?token=${token}`;
  await send(
    to,
    "Reset your JustWe password",
    `<p>Hi ${firstName},</p>
     <p>We received a request to reset your password. This link expires in 1 hour.</p>
     <p><a href="${url}">Reset my password</a></p>
     <p>If you didn't request this, you can safely ignore this email.</p>`
  );
}

/**
 * CRITICAL PRIVACY RULE: this email must never contain the other person's
 * name, photo, or any identifying detail. See spec §65.
 */
export async function sendMutualLikePendingEmail(to: string, firstName: string) {
  await send(
    to,
    "You have an update on JustWe",
    `<p>Hi ${firstName},</p>
     <p>Someone you expressed interest in has also expressed interest in you.
     Your community host will review the connection before communication can begin.</p>
     <p>You'll be notified as soon as a decision is made.</p>`
  );
}

export async function sendMatchApprovedEmail(to: string, firstName: string) {
  const url = `${APP_URL}/matches`;
  await send(
    to,
    "Your JustWe connection was approved",
    `<p>Hi ${firstName},</p>
     <p>Your community host approved a connection. You can now get to know each other.</p>
     <p><a href="${url}">View your match</a></p>`
  );
}

export async function sendMatchRejectedEmail(to: string, firstName: string) {
  await send(
    to,
    "An update on your JustWe connection",
    `<p>Hi ${firstName},</p>
     <p>Your community host reviewed a recent connection. It wasn't approved at this time.</p>`
  );
}

export async function sendJoinRequestDecisionEmail(to: string, firstName: string, communityName: string, approved: boolean) {
  await send(
    to,
    approved ? `You've joined ${communityName} on JustWe` : `An update on your ${communityName} request`,
    approved
      ? `<p>Hi ${firstName},</p><p>Your request to join <strong>${communityName}</strong> was approved. You can now discover members of this community.</p>`
      : `<p>Hi ${firstName},</p><p>Your request to join <strong>${communityName}</strong> was not approved at this time.</p>`
  );
}
