import type { LocationVisibility } from "@prisma/client";
import { getCountryName } from "./countries";

export type LocationInput = {
  country: string;
  region?: string | null;
  city?: string | null;
  locationVisibility: LocationVisibility;
};

/**
 * Formats a user's location for display to OTHER users, respecting the
 * owner's chosen visibility level. Never returns exact coordinates or
 * street-level information — those are never collected in the first place.
 */
export function formatPublicLocation(loc: LocationInput): string {
  const countryName = getCountryName(loc.country) ?? loc.country;

  switch (loc.locationVisibility) {
    case "CITY_COUNTRY":
      return loc.city ? `${loc.city}, ${countryName}` : loc.region ? `${loc.region}, ${countryName}` : countryName;
    case "REGION_COUNTRY":
      return loc.region ? `${loc.region}, ${countryName}` : countryName;
    case "COUNTRY_ONLY":
    default:
      return countryName;
  }
}
