import { z } from "zod";

export const MIN_AGE = 18;

function calcAge(dob: Date): number {
  const diff = Date.now() - dob.getTime();
  return Math.floor(diff / (365.25 * 24 * 60 * 60 * 1000));
}

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

export const registerSchema = z.object({
  email: z.string().email(),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Include at least one uppercase letter")
    .regex(/[0-9]/, "Include at least one number"),
  firstName: z.string().min(1).max(50),
  dateOfBirth: z
    .string()
    .refine((v) => !isNaN(Date.parse(v)), "Invalid date")
    .refine((v) => calcAge(new Date(v)) >= MIN_AGE, `You must be at least ${MIN_AGE} to join JustWe`),
  country: z.string().length(2),
});

export const forgotPasswordSchema = z.object({ email: z.string().email() });

export const resetPasswordSchema = z.object({
  token: z.string().min(10),
  password: z
    .string()
    .min(8)
    .regex(/[A-Z]/)
    .regex(/[0-9]/),
});

export const profileUpdateSchema = z.object({
  firstName: z.string().min(1).max(50).optional(),
  gender: z.enum(["MALE", "FEMALE"]).optional(),
  country: z.string().length(2).optional(),
  region: z.string().max(100).nullable().optional(),
  city: z.string().max(100).nullable().optional(),
  locationVisibility: z.enum(["COUNTRY_ONLY", "REGION_COUNTRY", "CITY_COUNTRY"]).optional(),
  bio: z.string().max(2000).nullable().optional(),
  jwStatus: z.enum(["BAPTIZED_PUBLISHER", "UNBAPTIZED_PUBLISHER", "STUDENT", "SYMPATHIZER", "OTHER"]).nullable().optional(),
  spiritualGoals: z.string().max(1000).nullable().optional(),
  lookingFor: z.string().max(1000).nullable().optional(),
  relationshipGoals: z.string().max(1000).nullable().optional(),
  marriageIntention: z.enum(["WITHIN_A_YEAR", "ONE_TO_TWO_YEARS", "WHEN_RIGHT_PERSON_FOUND", "NOT_SURE_YET"]).nullable().optional(),
  longDistancePreference: z.enum(["YES", "MAYBE", "NO"]).optional(),
  interests: z.array(z.string().max(40)).max(20).optional(),
  languages: z.array(z.string().max(40)).max(10).optional(),
  lifestyleNotes: z.string().max(1000).nullable().optional(),
});

export const activateDatingSchema = z.object({
  agreesToGenuineIntent: z.literal(true, {
    errorMap: () => ({ message: "You must confirm your genuine intention to activate dating" }),
  }),
});

export const communityCreateSchema = z.object({
  name: z.string().min(3).max(80),
  description: z.string().min(10).max(3000),
  hostIntroduction: z.string().max(1000).optional(),
  geographicFocus: z.enum([
    "WORLDWIDE", "AFRICA", "EUROPE", "NORTH_AMERICA", "SOUTH_AMERICA", "ASIA", "OCEANIA", "COUNTRY", "REGION", "CITY",
  ]),
  focusCountry: z.string().length(2).optional(),
  focusRegion: z.string().max(100).optional(),
  focusCity: z.string().max(100).optional(),
  imageUrl: z.string().url().optional(),
  visibility: z.enum(["PUBLIC", "INVITE_ONLY"]),
  rules: z.string().min(10).max(3000),
});

export const communityUpdateSchema = communityCreateSchema.partial();

export const joinRequestSchema = z.object({
  communityId: z.string().cuid(),
  introMessage: z.string().max(500).optional(),
});

export const membershipDecisionSchema = z.object({
  action: z.enum(["APPROVE", "REJECT", "REMOVE"]),
});

export const likeSchema = z.object({
  toUserId: z.string().cuid(),
  communityId: z.string().cuid(),
});

export const matchDecisionSchema = z.object({
  action: z.enum(["APPROVE", "REJECT"]),
});

export const messageSchema = z.object({
  matchId: z.string().cuid(),
  body: z.string().min(1).max(4000),
});

export const communityPostSchema = z.object({
  body: z.string().min(1).max(3000),
  imageUrl: z.string().url().optional(),
});

export const reportSchema = z.object({
  reportedUserId: z.string().cuid(),
  reason: z.enum(["FAKE_PROFILE", "HARASSMENT", "INAPPROPRIATE_BEHAVIOR", "MISREPRESENTATION", "SPAM", "OTHER"]),
  details: z.string().max(2000).optional(),
});

export const blockSchema = z.object({
  blockedId: z.string().cuid(),
});

export const photoUploadSchema = z.object({
  imageUrl: z.string().url(),
  thumbnailUrl: z.string().url().optional(),
  displayOrder: z.number().int().min(0).max(20).optional(),
});
