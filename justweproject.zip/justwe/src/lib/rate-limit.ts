/**
 * Lightweight rate limiter. For a single-instance deployment this in-memory
 * map is sufficient; for multi-instance/serverless production deployments,
 * swap this for Upstash Redis (`@upstash/ratelimit`) — the interface below
 * is designed to make that a drop-in change.
 */
type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();

export function rateLimit(key: string, limit: number, windowMs: number): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const existing = buckets.get(key);

  if (!existing || existing.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: limit - 1 };
  }

  if (existing.count >= limit) {
    return { allowed: false, remaining: 0 };
  }

  existing.count += 1;
  return { allowed: true, remaining: limit - existing.count };
}

/** Convenience for IP-based limiting keyed by route name. */
export function checkRateLimit(routeName: string, identifier: string, limit = 10, windowMs = 60_000) {
  return rateLimit(`${routeName}:${identifier}`, limit, windowMs);
}
