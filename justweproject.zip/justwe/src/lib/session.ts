import { getServerSession } from "next-auth";
import { authOptions } from "./auth";
import { db } from "./db";

/**
 * Returns the authenticated session or null. Use in Server Components / route handlers.
 */
export async function getSession() {
  return getServerSession(authOptions);
}

/**
 * Returns the full current User record from the DB, or null if unauthenticated.
 * Throws is intentionally avoided here — callers decide how to respond (401 vs redirect).
 */
export async function getCurrentUser() {
  const session = await getSession();
  if (!session?.user?.id) return null;
  const user = await db.user.findUnique({ where: { id: session.user.id } });
  if (!user || user.accountStatus !== "ACTIVE") return null;
  return user;
}

export class UnauthorizedError extends Error {
  status = 401;
  constructor(msg = "Unauthorized") {
    super(msg);
  }
}

export class ForbiddenError extends Error {
  status = 403;
  constructor(msg = "Forbidden") {
    super(msg);
  }
}

/** Throws UnauthorizedError if not logged in. Use at the top of protected API routes. */
export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) throw new UnauthorizedError();
  return user;
}

export async function requireAdmin() {
  const user = await requireUser();
  if (user.role !== "ADMIN") throw new ForbiddenError("Admin access required");
  return user;
}
