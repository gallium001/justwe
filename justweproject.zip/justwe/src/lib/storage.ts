import { S3Client, PutObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { v4 as uuid } from "uuid";

/**
 * Cloud object storage for profile photos & community images.
 * Works with AWS S3 or any S3-compatible provider (Cloudflare R2, Backblaze B2,
 * DigitalOcean Spaces). Configure via env vars — see .env.example.
 */
const s3 = new S3Client({
  region: process.env.S3_REGION || "auto",
  endpoint: process.env.S3_ENDPOINT, // omit for real AWS S3
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY_ID!,
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY!,
  },
});

const BUCKET = process.env.S3_BUCKET!;
const PUBLIC_BASE_URL = process.env.PUBLIC_MEDIA_URL!; // e.g. CDN / public bucket URL

export const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
export const MAX_IMAGE_BYTES = 8 * 1024 * 1024; // 8MB
export const MAX_PHOTOS_PER_USER = 9;

/**
 * Generates a presigned PUT URL so the browser can upload directly to object
 * storage (never proxying large binaries through the Next.js server).
 * `folder` namespaces uploads, e.g. "dating-photos", "community-images".
 */
export async function createPresignedUpload(opts: {
  userId: string;
  folder: "dating-photos" | "community-images" | "profile-photos" | "post-images";
  contentType: string;
}) {
  if (!ALLOWED_IMAGE_TYPES.includes(opts.contentType)) {
    throw new Error("Unsupported image type");
  }
  const ext = opts.contentType.split("/")[1];
  const key = `${opts.folder}/${opts.userId}/${uuid()}.${ext}`;

  const command = new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    ContentType: opts.contentType,
  });

  const uploadUrl = await getSignedUrl(s3, command, { expiresIn: 60 * 5 });
  const publicUrl = `${PUBLIC_BASE_URL}/${key}`;

  return { uploadUrl, publicUrl, key };
}

export async function deleteObject(key: string) {
  await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: key }));
}

/** Extracts the storage key from a public media URL, for deletion. */
export function keyFromPublicUrl(url: string): string | null {
  if (!url.startsWith(PUBLIC_BASE_URL)) return null;
  return url.slice(PUBLIC_BASE_URL.length + 1);
}
