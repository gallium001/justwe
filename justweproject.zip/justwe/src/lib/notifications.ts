import { db } from "./db";
import type { NotificationType } from "@prisma/client";

/**
 * Central notification creator. `metadata` is stored server-side for internal
 * routing (e.g. { matchId } so tapping the notification can deep-link), but
 * API serializers for notifications MUST NOT include any identity fields
 * (name, photo, userId of a counterparty) for MUTUAL_LIKE_PENDING or
 * MATCH_REJECTED notifications. Title/body are always pre-written to be
 * anonymous — never interpolate a counterparty's name into them.
 */
export async function createNotification(opts: {
  userId: string;
  type: NotificationType;
  title: string;
  body: string;
  metadata?: Record<string, unknown>;
}) {
  return db.notification.create({
    data: {
      userId: opts.userId,
      type: opts.type,
      title: opts.title,
      body: opts.body,
      metadata: opts.metadata as any,
    },
  });
}

export const NotificationCopy = {
  mutualLikePending: {
    title: "You have a new update",
    body: "You have a new update regarding someone you expressed interest in. Your community host will review the connection before communication can begin.",
  },
  matchApproved: {
    title: "Connection approved",
    body: "Your community host approved a connection. You can now get to know each other.",
  },
  matchRejected: {
    title: "Connection reviewed",
    body: "Your community host reviewed a recent connection. It wasn't approved at this time.",
  },
  joinRequestReceived: (applicantFirstName: string) => ({
    title: "New membership request",
    body: `${applicantFirstName} requested to join your community.`,
  }),
  joinApproved: (communityName: string) => ({
    title: "Membership approved",
    body: `You're now a member of ${communityName}.`,
  }),
  joinRejected: (communityName: string) => ({
    title: "Membership request update",
    body: `Your request to join ${communityName} was not approved.`,
  }),
  removedFromCommunity: (communityName: string) => ({
    title: "Removed from community",
    body: `You have been removed from ${communityName}.`,
  }),
  newPost: (communityName: string) => ({
    title: "New community post",
    body: `${communityName} shared a new post.`,
  }),
  newMessage: () => ({
    title: "New message",
    body: "You have a new message waiting for you.",
  }),
};
