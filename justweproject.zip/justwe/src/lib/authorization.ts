import { db } from "./db";
import { ForbiddenError } from "./session";

/**
 * ============================================================================
 * AUTHORIZATION / PRIVACY ENGINE
 * ============================================================================
 * Every rule described in the product spec that says "must be enforced
 * server-side" is implemented here. UI components must never be trusted to
 * hide sensitive data — they simply won't receive it, because these
 * functions are the only path data takes out of the database.
 *
 * Rules encoded in this file:
 *  1. A dating profile/gallery is visible to viewer V only if V and the
 *     owner share at least one community where BOTH have APPROVED
 *     membership, AND the owner has an active dating profile, AND
 *     neither has blocked the other.
 *  2. No distance/country filtering is ever applied — community membership
 *     is the only geographic gate.
 *  3. A pending Match's counterparty identity is never resolvable by either
 *     participant. Only a host of the match's community, or an admin, may
 *     resolve both identities.
 *  4. Removed/rejected/left members immediately lose access (status is
 *     checked live on every request, not cached).
 * ============================================================================
 */

/** Returns true if either user has blocked the other. */
export async function isBlockedEitherWay(userIdA: string, userIdB: string): Promise<boolean> {
  if (userIdA === userIdB) return false;
  const block = await db.block.findFirst({
    where: {
      OR: [
        { blockerId: userIdA, blockedId: userIdB },
        { blockerId: userIdB, blockedId: userIdA },
      ],
    },
    select: { id: true },
  });
  return !!block;
}

/** Community IDs where the user currently has APPROVED membership. */
export async function getApprovedCommunityIds(userId: string): Promise<string[]> {
  const memberships = await db.communityMembership.findMany({
    where: { userId, status: "APPROVED" },
    select: { communityId: true },
  });
  return memberships.map((m) => m.communityId);
}

/**
 * Determines whether `viewerId` is authorized to view `targetUserId`'s dating
 * profile and photo gallery. Returns the shared community id used (first
 * match) so callers can attribute a subsequent Like to the correct community,
 * or null if not authorized.
 */
export async function getAuthorizedSharedCommunity(
  viewerId: string,
  targetUserId: string
): Promise<{ communityId: string } | null> {
  if (viewerId === targetUserId) return null;

  const blocked = await isBlockedEitherWay(viewerId, targetUserId);
  if (blocked) return null;

  const target = await db.user.findUnique({
    where: { id: targetUserId },
    select: { datingProfileActive: true },
  });
  if (!target?.datingProfileActive) return null;

  const [viewerCommunities, targetCommunities] = await Promise.all([
    getApprovedCommunityIds(viewerId),
    getApprovedCommunityIds(targetUserId),
  ]);

  const shared = viewerCommunities.find((id) => targetCommunities.includes(id));
  if (!shared) return null;

  return { communityId: shared };
}

/** Throws ForbiddenError unless viewer is authorized to see target's dating profile. */
export async function requireProfileAccess(viewerId: string, targetUserId: string) {
  const result = await getAuthorizedSharedCommunity(viewerId, targetUserId);
  if (!result) throw new ForbiddenError("You do not have access to this profile");
  return result;
}

/**
 * Confirms `userId` currently holds APPROVED membership in `communityId`.
 * Used to gate Discover, community posts, and join-request-derived actions.
 */
export async function requireApprovedMember(userId: string, communityId: string) {
  const membership = await db.communityMembership.findUnique({
    where: { communityId_userId: { communityId, userId } },
    select: { status: true },
  });
  if (!membership || membership.status !== "APPROVED") {
    throw new ForbiddenError("You are not an approved member of this community");
  }
}

/** Confirms `userId` is the host of `communityId`. */
export async function requireCommunityHost(userId: string, communityId: string) {
  const community = await db.community.findUnique({
    where: { id: communityId },
    select: { hostId: true },
  });
  if (!community || community.hostId !== userId) {
    throw new ForbiddenError("You are not the host of this community");
  }
  return community;
}

/**
 * The critical anonymity boundary: given a Match and the requesting user id,
 * returns ONLY what a non-host participant is allowed to see. Never includes
 * the counterparty's id, name, or any field derived from it while pending or
 * rejected. Only once APPROVED does the counterparty become resolvable, and
 * even then, only to the two participants (never to unrelated users).
 */
export function serializeMatchForParticipant(
  match: {
    id: string;
    userAId: string;
    userBId: string;
    status: "PENDING_HOST_REVIEW" | "APPROVED" | "REJECTED";
    createdAt: Date;
    reviewedAt: Date | null;
  },
  requestingUserId: string
) {
  const isParticipant = match.userAId === requestingUserId || match.userBId === requestingUserId;
  if (!isParticipant) {
    throw new ForbiddenError("Not a participant in this match");
  }

  if (match.status !== "APPROVED") {
    // Anonymous shape — no counterparty id anywhere in this object.
    return {
      id: match.id,
      status: match.status,
      createdAt: match.createdAt,
      reviewedAt: match.reviewedAt,
    };
  }

  // Approved — safe to include counterparty id; caller fetches full profile
  // separately through requireProfileAccess-gated profile endpoints.
  const otherUserId = match.userAId === requestingUserId ? match.userBId : match.userAId;
  return {
    id: match.id,
    status: match.status,
    createdAt: match.createdAt,
    reviewedAt: match.reviewedAt,
    otherUserId,
  };
}

/**
 * Full match resolution for a host/admin reviewing a pending match. Verifies
 * the requester is actually the host of the match's community (or admin)
 * before returning identity-bearing data.
 */
export async function requireHostMatchAccess(requesterId: string, requesterRole: string, matchId: string) {
  const match = await db.match.findUnique({
    where: { id: matchId },
    include: { community: { select: { hostId: true } } },
  });
  if (!match) throw new ForbiddenError("Match not found");

  const isHost = match.community.hostId === requesterId;
  const isAdmin = requesterRole === "ADMIN";
  if (!isHost && !isAdmin) {
    throw new ForbiddenError("Only the community host may review this match");
  }
  return match;
}
