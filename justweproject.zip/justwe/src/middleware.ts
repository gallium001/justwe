import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

export default withAuth(
  function middleware(req) {
    const { pathname } = req.nextUrl;
    const token = (req as any).nextauth?.token;

    if (pathname.startsWith("/admin") && token?.role !== "ADMIN") {
      return NextResponse.redirect(new URL("/communities", req.url));
    }
    if (pathname.startsWith("/api/admin") && token?.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }
    return NextResponse.next();
  },
  {
    callbacks: {
      authorized: ({ token }) => !!token,
    },
  }
);

export const config = {
  matcher: [
    "/communities/:path*",
    "/discover/:path*",
    "/matches/:path*",
    "/messages/:path*",
    "/profile/:path*",
    "/profiles/:path*",
    "/settings/:path*",
    "/host/:path*",
    "/admin/:path*",
    "/api/me/:path*",
    "/api/communities/:path*",
    "/api/profiles/:path*",
    "/api/likes/:path*",
    "/api/matches/:path*",
    "/api/host/:path*",
    "/api/messages/:path*",
    "/api/notifications/:path*",
    "/api/block/:path*",
    "/api/report/:path*",
    "/api/admin/:path*",
    "/api/uploads/:path*",
    "/api/my/:path*",
  ],
};
