import { beforeAll, afterAll } from "vitest";
import { db } from "@/lib/db";

beforeAll(async () => {
  // Requires DATABASE_URL to point at a disposable test database.
  // Order matters due to FK constraints.
  await db.message.deleteMany();
  await db.match.deleteMany();
  await db.like.deleteMany();
  await db.datingPhotoView.deleteMany();
  await db.datingPhoto.deleteMany();
  await db.communityPost.deleteMany();
  await db.notification.deleteMany();
  await db.block.deleteMany();
  await db.report.deleteMany();
  await db.communityMembership.deleteMany();
  await db.community.deleteMany();
  await db.hostVerification.deleteMany();
  await db.passwordResetToken.deleteMany();
  await db.emailVerificationToken.deleteMany();
  await db.user.deleteMany();
});

afterAll(async () => {
  await db.$disconnect();
});
