import { describe, it, expect } from "vitest";
import { db } from "@/lib/db";
import { getAuthorizedSharedCommunity, requireApprovedMember } from "@/lib/authorization";
import { makeUser, makeCommunity, approveMembership, pendingMembership } from "../factories";

describe("Community access boundaries", () => {
  it("denies profile access to a non-member", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id);
    const viewer = await makeUser({ country: "US" });
    const owner = await makeUser({ country: "US" });
    await approveMembership(community.id, owner.id, host.id);
    // viewer never joined

    const result = await getAuthorizedSharedCommunity(viewer.id, owner.id);
    expect(result).toBeNull();
  });

  it("denies access to profiles for PENDING (not yet approved) members", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id);
    const viewer = await makeUser();
    const owner = await makeUser();
    await pendingMembership(community.id, viewer.id); // pending, not approved
    await approveMembership(community.id, owner.id, host.id);

    const result = await getAuthorizedSharedCommunity(viewer.id, owner.id);
    expect(result).toBeNull();

    await expect(requireApprovedMember(viewer.id, community.id)).rejects.toThrow();
  });

  it("allows worldwide discovery regardless of country — Finland <-> Kenya", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id, { geographicFocus: "WORLDWIDE" });

    const finnishUser = await makeUser({ country: "FI", region: "Central Finland" });
    const kenyanUser = await makeUser({ country: "KE", region: "Nairobi" });

    await approveMembership(community.id, finnishUser.id, host.id);
    await approveMembership(community.id, kenyanUser.id, host.id);

    const result = await getAuthorizedSharedCommunity(finnishUser.id, kenyanUser.id);
    expect(result).not.toBeNull();
    expect(result?.communityId).toBe(community.id);
  });

  it("immediately revokes access after a member is REMOVED", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id);
    const viewer = await makeUser();
    const owner = await makeUser();
    const membership = await approveMembership(community.id, viewer.id, host.id);
    await approveMembership(community.id, owner.id, host.id);

    // Confirm access works while approved.
    expect(await getAuthorizedSharedCommunity(viewer.id, owner.id)).not.toBeNull();

    // Host removes the member.
    await db.communityMembership.update({ where: { id: membership.id }, data: { status: "REMOVED" } });

    const result = await getAuthorizedSharedCommunity(viewer.id, owner.id);
    expect(result).toBeNull();
  });

  it("does not expose profiles whose dating profile is inactive", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id);
    const viewer = await makeUser();
    const owner = await makeUser({ datingProfileActive: false });
    await approveMembership(community.id, viewer.id, host.id);
    await approveMembership(community.id, owner.id, host.id);

    const result = await getAuthorizedSharedCommunity(viewer.id, owner.id);
    expect(result).toBeNull();
  });
});
