import { describe, it, expect } from "vitest";
import { db } from "@/lib/db";
import { makeUser, makeCommunity, approveMembership } from "../factories";
import { PHOTO_VIEW_DEBOUNCE_MS } from "@/lib/utils";

/**
 * Mirrors the recordViews logic in src/app/api/profiles/[userId]/photos/route.ts
 * to test the debounce/aggregation behavior in isolation without spinning up
 * a full Next.js server.
 */
async function recordView(viewerId: string, photoId: string, profileOwnerId: string) {
  const cutoff = new Date(Date.now() - PHOTO_VIEW_DEBOUNCE_MS);
  const recent = await db.datingPhotoView.findFirst({ where: { photoId, viewerId, createdAt: { gte: cutoff } } });
  if (recent) return false;
  await db.$transaction([
    db.datingPhotoView.create({ data: { photoId, viewerId, profileOwnerId } }),
    db.datingPhoto.update({ where: { id: photoId }, data: { viewCount: { increment: 1 } } }),
  ]);
  return true;
}

describe("Photo view tracking & privacy", () => {
  it("records a view and increments the aggregate count", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id);
    const owner = await makeUser();
    const viewer = await makeUser();
    await approveMembership(community.id, owner.id, host.id);
    await approveMembership(community.id, viewer.id, host.id);

    const photo = await db.datingPhoto.create({ data: { userId: owner.id, imageUrl: "https://example.com/a.jpg" } });

    await recordView(viewer.id, photo.id, owner.id);

    const updated = await db.datingPhoto.findUnique({ where: { id: photo.id } });
    expect(updated?.viewCount).toBe(1);
  });

  it("does not inflate the count on rapid repeated views from the same viewer", async () => {
    const owner = await makeUser();
    const viewer = await makeUser();
    const photo = await db.datingPhoto.create({ data: { userId: owner.id, imageUrl: "https://example.com/b.jpg" } });

    await recordView(viewer.id, photo.id, owner.id);
    await recordView(viewer.id, photo.id, owner.id); // within debounce window — should not count again

    const updated = await db.datingPhoto.findUnique({ where: { id: photo.id } });
    expect(updated?.viewCount).toBe(1);
  });

  it("never exposes individual viewer identity via the photo/photoView models to a non-owner query surface", async () => {
    const owner = await makeUser();
    const viewer = await makeUser();
    const photo = await db.datingPhoto.create({ data: { userId: owner.id, imageUrl: "https://example.com/c.jpg" } });
    await recordView(viewer.id, photo.id, owner.id);

    // Simulate the public/gallery API's select shape — no viewCount, no viewer fields.
    const publicShape = await db.datingPhoto.findUnique({
      where: { id: photo.id },
      select: { id: true, imageUrl: true, thumbnailUrl: true, displayOrder: true },
    });
    expect(Object.keys(publicShape as object)).not.toContain("viewCount");

    // Simulate the owner's own shape — aggregate count only, no viewer id.
    const ownerShape = await db.datingPhoto.findUnique({
      where: { id: photo.id },
      select: { id: true, viewCount: true },
    });
    expect(ownerShape?.viewCount).toBe(1);
    expect(JSON.stringify(ownerShape)).not.toContain(viewer.id);
  });
});
