import { describe, it, expect } from "vitest";
import { db } from "@/lib/db";
import { makeUser, makeCommunity, approveMembership } from "../factories";

/** Mirrors assertApprovedParticipant in src/app/api/messages/[matchId]/route.ts */
async function assertApprovedParticipant(userId: string, matchId: string) {
  const match = await db.match.findUnique({ where: { id: matchId } });
  if (!match) throw new Error("Match not found");
  const isParticipant = match.userAId === userId || match.userBId === userId;
  if (!isParticipant) throw new Error("Not a participant");
  if (match.status !== "APPROVED") throw new Error("Messaging is only available after host approval");
  return match;
}

describe("Messaging access", () => {
  it("blocks messaging while a match is PENDING_HOST_REVIEW", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id);
    const a = await makeUser();
    const b = await makeUser();
    await approveMembership(community.id, a.id, host.id);
    await approveMembership(community.id, b.id, host.id);

    const [first, second] = [a.id, b.id].sort();
    const match = await db.match.create({ data: { userAId: first, userBId: second, communityId: community.id, status: "PENDING_HOST_REVIEW" } });

    await expect(assertApprovedParticipant(a.id, match.id)).rejects.toThrow(/host approval/);
  });

  it("allows messaging once a match is APPROVED", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id);
    const a = await makeUser();
    const b = await makeUser();
    await approveMembership(community.id, a.id, host.id);
    await approveMembership(community.id, b.id, host.id);

    const [first, second] = [a.id, b.id].sort();
    const match = await db.match.create({ data: { userAId: first, userBId: second, communityId: community.id, status: "APPROVED", reviewedBy: host.id, reviewedAt: new Date() } });

    await expect(assertApprovedParticipant(a.id, match.id)).resolves.toBeDefined();

    const message = await db.message.create({
      data: { matchId: match.id, senderId: a.id, receiverId: b.id, body: "Hello!" },
    });
    expect(message.body).toBe("Hello!");
  });

  it("blocks a non-participant from messaging in someone else's match", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id);
    const a = await makeUser();
    const b = await makeUser();
    const outsider = await makeUser();
    await approveMembership(community.id, a.id, host.id);
    await approveMembership(community.id, b.id, host.id);

    const [first, second] = [a.id, b.id].sort();
    const match = await db.match.create({ data: { userAId: first, userBId: second, communityId: community.id, status: "APPROVED" } });

    await expect(assertApprovedParticipant(outsider.id, match.id)).rejects.toThrow(/participant/);
  });
});
