import { describe, it, expect } from "vitest";
import { db } from "@/lib/db";
import { serializeMatchForParticipant, requireHostMatchAccess } from "@/lib/authorization";
import { makeUser, makeCommunity, approveMembership } from "../factories";

describe("Anonymous mutual-match privacy", () => {
  it("never includes the counterparty's identity while PENDING_HOST_REVIEW", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id);
    const userA = await makeUser();
    const userB = await makeUser();
    await approveMembership(community.id, userA.id, host.id);
    await approveMembership(community.id, userB.id, host.id);

    const [first, second] = [userA.id, userB.id].sort();
    const match = await db.match.create({
      data: { userAId: first, userBId: second, communityId: community.id, status: "PENDING_HOST_REVIEW" },
    });

    const viewFromA = serializeMatchForParticipant(match, userA.id);
    const viewFromB = serializeMatchForParticipant(match, userB.id);

    // Assert the serialized object has no key that could identify the other party.
    expect(Object.keys(viewFromA)).not.toContain("otherUserId");
    expect(Object.keys(viewFromA)).not.toContain("userAId");
    expect(Object.keys(viewFromA)).not.toContain("userBId");
    expect(JSON.stringify(viewFromA)).not.toContain(userA.id === first ? second : first);

    expect(Object.keys(viewFromB)).not.toContain("otherUserId");
    expect(viewFromA.status).toBe("PENDING_HOST_REVIEW");
    expect(viewFromB.status).toBe("PENDING_HOST_REVIEW");
  });

  it("stays anonymous after REJECTION — never reveals who the other person was", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id);
    const userA = await makeUser();
    const userB = await makeUser();
    await approveMembership(community.id, userA.id, host.id);
    await approveMembership(community.id, userB.id, host.id);

    const [first, second] = [userA.id, userB.id].sort();
    const match = await db.match.create({
      data: { userAId: first, userBId: second, communityId: community.id, status: "REJECTED", reviewedBy: host.id, reviewedAt: new Date() },
    });

    const view = serializeMatchForParticipant(match, userA.id);
    expect(Object.keys(view)).not.toContain("otherUserId");
    expect(view.status).toBe("REJECTED");
  });

  it("reveals the counterparty's id ONLY after APPROVAL, and only to participants", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id);
    const userA = await makeUser();
    const userB = await makeUser();
    const outsider = await makeUser();
    await approveMembership(community.id, userA.id, host.id);
    await approveMembership(community.id, userB.id, host.id);

    const [first, second] = [userA.id, userB.id].sort();
    const match = await db.match.create({
      data: { userAId: first, userBId: second, communityId: community.id, status: "APPROVED", reviewedBy: host.id, reviewedAt: new Date() },
    });

    const view = serializeMatchForParticipant(match, userA.id);
    expect((view as any).otherUserId).toBe(userA.id === first ? second : first);

    expect(() => serializeMatchForParticipant(match, outsider.id)).toThrow();
  });

  it("only the community's host (or admin) can resolve full identities of a pending match", async () => {
    const host = await makeUser();
    const otherHost = await makeUser();
    const community = await makeCommunity(host.id);
    const userA = await makeUser();
    const userB = await makeUser();
    await approveMembership(community.id, userA.id, host.id);
    await approveMembership(community.id, userB.id, host.id);

    const [first, second] = [userA.id, userB.id].sort();
    const match = await db.match.create({
      data: { userAId: first, userBId: second, communityId: community.id, status: "PENDING_HOST_REVIEW" },
    });

    // Correct host succeeds.
    await expect(requireHostMatchAccess(host.id, "USER", match.id)).resolves.toBeDefined();

    // An unrelated host is rejected.
    await expect(requireHostMatchAccess(otherHost.id, "USER", match.id)).rejects.toThrow();

    // Admin succeeds regardless of hosting relationship.
    await expect(requireHostMatchAccess(otherHost.id, "ADMIN", match.id)).resolves.toBeDefined();
  });
});
