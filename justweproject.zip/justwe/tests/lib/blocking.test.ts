import { describe, it, expect } from "vitest";
import { db } from "@/lib/db";
import { getAuthorizedSharedCommunity, isBlockedEitherWay } from "@/lib/authorization";
import { makeUser, makeCommunity, approveMembership } from "../factories";

describe("Blocking", () => {
  it("detects a block in either direction", async () => {
    const a = await makeUser();
    const b = await makeUser();
    await db.block.create({ data: { blockerId: a.id, blockedId: b.id } });

    expect(await isBlockedEitherWay(a.id, b.id)).toBe(true);
    expect(await isBlockedEitherWay(b.id, a.id)).toBe(true);
  });

  it("prevents a blocked user from accessing the other's dating profile", async () => {
    const host = await makeUser();
    const community = await makeCommunity(host.id);
    const a = await makeUser();
    const b = await makeUser();
    await approveMembership(community.id, a.id, host.id);
    await approveMembership(community.id, b.id, host.id);

    expect(await getAuthorizedSharedCommunity(a.id, b.id)).not.toBeNull();

    await db.block.create({ data: { blockerId: b.id, blockedId: a.id } });

    expect(await getAuthorizedSharedCommunity(a.id, b.id)).toBeNull();
    expect(await getAuthorizedSharedCommunity(b.id, a.id)).toBeNull();
  });
});
